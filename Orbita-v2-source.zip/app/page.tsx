"use client";
import OrbitaApp from "@/components/orbita/app";

export default function Home() {
  return <OrbitaApp />;
}
