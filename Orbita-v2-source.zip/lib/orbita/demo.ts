import type { Lead, Stage } from "./types";
import { SEGMENT_BY_ID } from "./segments";

/** Dados fictícios para explorar o painel sem chave. Todos marcados com `demo: true`. */
const NAMES: [string, string][] = [
  ["restaurant", "Cantinho do Sertão"], ["restaurant", "Casa Jangada"], ["restaurant", "Tempero da Serra"], ["restaurant", "Bistrô Maresia"],
  ["cafe", "Café Mandacaru"], ["cafe", "Grão Nordeste"], ["bakery", "Padaria Estrela do Norte"], ["bakery", "Doce Cajuína"],
  ["barber", "Barbearia Navalha de Ouro"], ["barber", "Studio Cachos & Cia"], ["beauty", "Espaço Bem-Estar Iracema"], ["beauty", "Clínica Pele de Sol"],
  ["dentist", "Sorriso Aldeota Odontologia"], ["dentist", "OdontoVida Benfica"], ["clinic", "Clínica Integrar"], ["gym", "Academia Força Litoral"],
  ["gym", "Studio Pulso Funcional"], ["hotel", "Pousada Vento Leste"], ["hotel", "Hotel Mirante do Mar"], ["auto", "Auto Center Carcará"],
  ["vehicle", "Som & Acessórios Beira-Rio"], ["pet", "Pet Shop Rabo Feliz"], ["veterinary", "Vet Cuidar"], ["lawyer", "Menezes & Rocha Advocacia"],
  ["accountant", "Contábil Horizonte"], ["estate", "Imobiliária Porto Seguro do Ceará"], ["photographer", "Luz de Janela Fotografia"], ["clothing", "Ateliê Renda Viva"],
  ["furniture", "Casa Carnaúba Decor"], ["optician", "Ótica Visão Clara"], ["driving", "Autoescola Rota Certa"], ["language", "Speak Up Idiomas"],
  ["tattoo", "Tinta Nordeste Tattoo"], ["icecream", "Gelato da Praia"], ["florist", "Flor de Mandacaru"], ["laundry", "Lavanderia Bolha Azul"],
];
const SUBURBS = ["Aldeota", "Meireles", "Centro", "Benfica", "Fátima", "Varjota", "Dionísio Torres", "Joaquim Távora", "Parquelândia", "Papicu", "Cocó", "Montese"];
const STREETS = ["Rua Barbosa de Freitas", "Av. Santos Dumont", "Rua Tibúrcio Cavalcante", "Av. Dom Luís", "Rua Silva Paulet", "Av. da Universidade", "Rua Canuto de Aguiar", "Av. Treze de Maio", "Rua Padre Valdevino", "Av. Desembargador Moreira"];

function rng(seed: number) {
  return () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
}

export function buildDemoLeads(): Lead[] {
  const r = rng(20260926);
  for (let i = 0; i < 10; i++) r();
  const center = { lat: -3.7319, lon: -38.5267 };
  const now = Date.now();
  const stages: Stage[] = ["novo", "novo", "novo", "novo", "qualificado", "qualificado", "contatado", "contatado", "negociando", "fechado", "perdido"];
  return NAMES.map(([segment, name], i) => {
    const seg = SEGMENT_BY_ID[segment];
    const angle = r() * Math.PI * 2, dist = 400 + r() * 5400;
    const lat = center.lat + (Math.sin(angle) * dist) / 111320;
    const lon = center.lon + (Math.cos(angle) * dist) / (111320 * Math.cos((center.lat * Math.PI) / 180));
    const hasPhone = r() > 0.2, mobile = r() > 0.35, hasIg = r() > 0.4, hasEmail = r() > 0.72, hasHours = r() > 0.45;
    const handle = name.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 22);
    const status = stages[Math.floor(r() * stages.length)];
    const foundAt = new Date(now - Math.floor(r() * 12 * 86400000)).toISOString();
    const days = Math.floor(r() * 9) - 3;
    const follow = ["contatado", "negociando", "qualificado"].includes(status) ? new Date(now + days * 86400000).toISOString().slice(0, 10) : "";
    const value = status === "negociando" || status === "fechado" ? [1200, 1800, 2500, 3200, 4500][Math.floor(r() * 5)] : 0;
    const suburb = SUBURBS[Math.floor(r() * SUBURBS.length)];
    const phone = hasPhone ? (mobile ? `(85) 9${String(8000 + Math.floor(r() * 1999))}-${String(1000 + Math.floor(r() * 8999))}` : `(85) 3${String(200 + Math.floor(r() * 799))}-${String(1000 + Math.floor(r() * 8999))}`) : "";
    const history: Lead["history"] = [{ at: foundAt, text: "Lead encontrado na busca", kind: "system" }];
    if (status !== "novo") history.push({ at: new Date(new Date(foundAt).getTime() + 86400000).toISOString(), text: `Estágio alterado para ${status}`, kind: "stage" });
    return {
      id: `demo:${i}`,
      name,
      segment,
      category: seg.short,
      city: "Fortaleza, Brasil",
      address: `${STREETS[Math.floor(r() * STREETS.length)]}, ${100 + Math.floor(r() * 2800)}`,
      suburb,
      postcode: "60000-000",
      phone,
      whatsapp: "",
      email: hasEmail ? `contato@${handle}.com.br` : "",
      instagramUrl: hasIg ? `https://www.instagram.com/${handle}/` : "",
      facebookUrl: "",
      openingHours: hasHours ? "Mo-Fr 08:00-18:00; Sa 08:00-12:00" : "",
      socialOnly: hasIg && r() > 0.65,
      distance: Math.round(dist),
      mapsUrl: `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=18/${lat}/${lon}`,
      lat,
      lon,
      status,
      selected: false,
      starred: r() > 0.85,
      notes: status === "negociando" ? "Pediu orçamento com agendamento online. Retornar com proposta." : status === "fechado" ? "Site institucional + botão WhatsApp. Entrada paga." : "",
      followUp: follow,
      value,
      foundAt,
      updatedAt: foundAt,
      history,
      demo: true,
    };
  });
}
