import type { Lead } from "./types";
import { SEGMENT_BY_ID } from "./segments";
import { isLikelyMobile } from "./utils";

export type ScoreFactor = { label: string; points: number; hit: boolean };
export type Heat = "quente" | "morno" | "frio";

/**
 * Lead score (0–100): quanto esse negócio tende a responder e a pagar por um site.
 * Transparente de propósito — cada fator aparece na ficha do lead.
 */
export function scoreFactors(lead: Lead): ScoreFactor[] {
  const tier = SEGMENT_BY_ID[lead.segment]?.tier ?? 1;
  const mobile = isLikelyMobile(lead);
  return [
    { label: "Tem telefone cadastrado", points: 18, hit: !!lead.phone || !!lead.whatsapp },
    { label: "Número com cara de WhatsApp", points: 12, hit: mobile },
    { label: "Instagram ativo, mas sem site", points: 16, hit: !!lead.instagramUrl },
    { label: "Usa rede social no lugar do site", points: 8, hit: lead.socialOnly },
    { label: "E-mail público", points: 5, hit: !!lead.email },
    { label: "Horário de funcionamento informado", points: 5, hit: !!lead.openingHours },
    { label: "Endereço completo", points: 4, hit: !!lead.address },
    { label: tier === 3 ? "Segmento de ticket alto" : tier === 2 ? "Segmento de ticket médio" : "Segmento de ticket de entrada", points: tier === 3 ? 20 : tier === 2 ? 13 : 7, hit: true },
    { label: "Base: sem site cadastrado", points: 12, hit: true },
  ];
}

export function leadScore(lead: Lead): number {
  return Math.min(100, scoreFactors(lead).reduce((sum, f) => sum + (f.hit ? f.points : 0), 0));
}

export function heatOf(score: number): Heat {
  return score >= 65 ? "quente" : score >= 42 ? "morno" : "frio";
}

export const HEAT_LABEL: Record<Heat, string> = { quente: "Quente", morno: "Morno", frio: "Frio" };
