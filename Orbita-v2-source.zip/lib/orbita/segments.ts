/**
 * Segmentos de busca. Compartilhado entre o backend (/api/search) e o painel.
 * `key`  → categorias Geoapify (separadas por vírgula).
 * `tier` → potencial de ticket para um projeto de site (usado no lead score).
 */
export type SegmentGroup =
  | "Alimentação"
  | "Beleza e bem-estar"
  | "Saúde"
  | "Serviços profissionais"
  | "Comércio"
  | "Automotivo"
  | "Educação"
  | "Turismo"
  | "Pets";

export type Segment = {
  id: string;
  key: string;
  label: string;
  short: string;
  group: SegmentGroup;
  tier: 1 | 2 | 3;
};

export const SEGMENTS: Segment[] = [
  { id: "restaurant", key: "catering.restaurant", label: "Restaurantes", short: "Restaurante", group: "Alimentação", tier: 1 },
  { id: "cafe", key: "catering.cafe", label: "Cafeterias", short: "Cafeteria", group: "Alimentação", tier: 1 },
  { id: "fastfood", key: "catering.fast_food", label: "Lanchonetes", short: "Lanchonete", group: "Alimentação", tier: 1 },
  { id: "bar", key: "catering.bar,catering.pub", label: "Bares", short: "Bar", group: "Alimentação", tier: 1 },
  { id: "icecream", key: "catering.ice_cream,commercial.food_and_drink.ice_cream", label: "Sorveterias", short: "Sorveteria", group: "Alimentação", tier: 1 },
  { id: "bakery", key: "commercial.food_and_drink.bakery,commercial.food_and_drink.confectionery", label: "Padarias e confeitarias", short: "Padaria", group: "Alimentação", tier: 1 },

  { id: "barber", key: "service.beauty.hairdresser", label: "Barbearias e salões", short: "Salão", group: "Beleza e bem-estar", tier: 2 },
  { id: "beauty", key: "service.beauty", label: "Estética", short: "Estética", group: "Beleza e bem-estar", tier: 2 },
  { id: "tattoo", key: "service.beauty.tattoo", label: "Estúdios de tatuagem", short: "Tatuagem", group: "Beleza e bem-estar", tier: 2 },
  { id: "gym", key: "sport.fitness.fitness_centre", label: "Academias", short: "Academia", group: "Beleza e bem-estar", tier: 3 },

  { id: "dentist", key: "healthcare.dentist", label: "Clínicas odontológicas", short: "Odontologia", group: "Saúde", tier: 3 },
  { id: "clinic", key: "healthcare.clinic_or_praxis", label: "Clínicas médicas", short: "Clínica", group: "Saúde", tier: 3 },
  { id: "pharmacy", key: "healthcare.pharmacy", label: "Farmácias", short: "Farmácia", group: "Saúde", tier: 1 },
  { id: "optician", key: "commercial.health_and_beauty.optician", label: "Óticas", short: "Ótica", group: "Saúde", tier: 2 },

  { id: "lawyer", key: "office.lawyer", label: "Escritórios de advocacia", short: "Advocacia", group: "Serviços profissionais", tier: 3 },
  { id: "accountant", key: "office.accountant,office.tax_advisor", label: "Contabilidade", short: "Contabilidade", group: "Serviços profissionais", tier: 3 },
  { id: "estate", key: "office.estate_agent,service.estate_agent", label: "Imobiliárias", short: "Imobiliária", group: "Serviços profissionais", tier: 3 },
  { id: "architect", key: "office.architect", label: "Arquitetura", short: "Arquitetura", group: "Serviços profissionais", tier: 3 },
  { id: "photographer", key: "service.photographer", label: "Fotógrafos", short: "Fotografia", group: "Serviços profissionais", tier: 2 },
  { id: "laundry", key: "service.cleaning.laundry,service.cleaning.dry_cleaning", label: "Lavanderias", short: "Lavanderia", group: "Serviços profissionais", tier: 1 },

  { id: "retail", key: "commercial.clothing,commercial.elektronics,commercial.furniture_and_interior,commercial.florist,commercial.books", label: "Lojas em geral", short: "Loja", group: "Comércio", tier: 2 },
  { id: "clothing", key: "commercial.clothing", label: "Moda e vestuário", short: "Moda", group: "Comércio", tier: 2 },
  { id: "furniture", key: "commercial.furniture_and_interior", label: "Móveis e decoração", short: "Decoração", group: "Comércio", tier: 2 },
  { id: "jewelry", key: "commercial.jewelry,commercial.watches", label: "Joalherias", short: "Joalheria", group: "Comércio", tier: 2 },
  { id: "florist", key: "commercial.florist", label: "Floriculturas", short: "Floricultura", group: "Comércio", tier: 1 },

  { id: "auto", key: "service.vehicle.repair.car", label: "Oficinas mecânicas", short: "Oficina", group: "Automotivo", tier: 2 },
  { id: "vehicle", key: "commercial.vehicle", label: "Autopeças e acessórios", short: "Autopeças", group: "Automotivo", tier: 2 },

  { id: "driving", key: "education.driving_school", label: "Autoescolas", short: "Autoescola", group: "Educação", tier: 3 },
  { id: "language", key: "education.language_school", label: "Escolas de idiomas", short: "Idiomas", group: "Educação", tier: 3 },
  { id: "music", key: "education.music_school", label: "Escolas de música", short: "Música", group: "Educação", tier: 2 },

  { id: "hotel", key: "accommodation.hotel,accommodation.guest_house,accommodation.hostel", label: "Hotéis e pousadas", short: "Hospedagem", group: "Turismo", tier: 3 },
  { id: "travel", key: "office.travel_agent", label: "Agências de viagem", short: "Agência", group: "Turismo", tier: 3 },

  { id: "pet", key: "pet.shop,pet.service", label: "Pet shops", short: "Pet shop", group: "Pets", tier: 2 },
  { id: "veterinary", key: "pet.veterinary", label: "Veterinárias", short: "Veterinária", group: "Pets", tier: 2 },
];

export const SEGMENT_BY_ID: Record<string, Segment> = Object.fromEntries(SEGMENTS.map((s) => [s.id, s]));

export const SEGMENT_GROUPS: SegmentGroup[] = [
  "Alimentação",
  "Beleza e bem-estar",
  "Saúde",
  "Serviços profissionais",
  "Comércio",
  "Automotivo",
  "Educação",
  "Turismo",
  "Pets",
];

/** Legado v1 usava o rótulo em português como categoria. */
export function segmentFromLegacyLabel(label: string): string {
  const legacy: Record<string, string> = {
    Restaurante: "restaurant", Cafeteria: "cafe", "Barbearia ou salão": "barber", "Estética": "beauty",
    Odontologia: "dentist", Academia: "gym", Hospedagem: "hotel", Padaria: "bakery", Oficina: "auto",
    Loja: "retail", "Farmácia": "pharmacy", "Veterinária": "veterinary",
  };
  return legacy[label] || "retail";
}
