import type { Settings, Template } from "./types";

export const DEFAULT_TEMPLATES: Template[] = [
  {
    id: "primeiro-contato",
    name: "Primeiro contato",
    body:
      "Oi, tudo bem? Aqui é {meu_nome}, da {minha_empresa}.\n\n" +
      "Encontrei a {nome} pesquisando {segmento} em {bairro} e percebi que vocês ainda não têm um site próprio. " +
      "Hoje muita gente procura no Google antes de ir até o local — e sem site esse cliente acaba indo para o concorrente.\n\n" +
      "Crio sites rápidos, bonitos e pensados para celular, com botão direto para o WhatsApp. " +
      "Posso te mostrar um exemplo de como ficaria o da {nome}, sem compromisso?",
  },
  {
    id: "so-instagram",
    name: "Só tem Instagram",
    body:
      "Oi! Vi o perfil da {nome} ({instagram}) e o trabalho de vocês é muito bom.\n\n" +
      "Notei que quem procura {segmento} em {cidade} no Google não encontra um site de vocês — só o Instagram, " +
      "que não aparece bem nas buscas. Sou {meu_nome}, da {minha_empresa}, e faço sites que transformam essas buscas em mensagens no WhatsApp.\n\n" +
      "Posso te mandar uma prévia gratuita?",
  },
  {
    id: "follow-up",
    name: "Follow-up",
    body:
      "Oi, tudo certo? Passando para retomar nossa conversa sobre o site da {nome}.\n\n" +
      "Separei alguns exemplos que fiz para {segmento}: {portfolio}\n\n" +
      "Se fizer sentido, consigo deixar tudo no ar em poucos dias. Que tal uma conversa rápida de 10 minutos?",
  },
];

export const DEFAULT_SETTINGS: Settings = {
  theme: "dark",
  profile: { name: "", company: "", portfolio: "" },
  templates: DEFAULT_TEMPLATES,
  defaultTemplate: "primeiro-contato",
  radius: 6000,
  depth: 1,
  excludeChains: true,
  recentPlaces: ["Fortaleza, Brasil"],
};

export const STORAGE_LEADS = "orbita-leads-v2";
export const STORAGE_LEADS_V1 = "orbita-leads-v1";
export const STORAGE_SETTINGS = "orbita-settings-v1";
export const STORAGE_KEY = "orbita-geoapify-key";
