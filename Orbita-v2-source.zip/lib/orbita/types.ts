export type Stage = "novo" | "qualificado" | "contatado" | "negociando" | "fechado" | "perdido";

export type HistoryEntry = { at: string; text: string; kind: "system" | "stage" | "note" | "contact" };

export type Lead = {
  id: string;
  name: string;
  segment: string;
  category: string;
  city: string;
  address: string;
  suburb: string;
  postcode: string;
  phone: string;
  whatsapp: string;
  email: string;
  instagramUrl: string;
  facebookUrl: string;
  openingHours: string;
  socialOnly: boolean;
  distance: number | null;
  mapsUrl: string;
  lat: number;
  lon: number;
  status: Stage;
  selected: boolean;
  starred: boolean;
  notes: string;
  followUp: string;
  value: number;
  foundAt: string;
  updatedAt: string;
  history: HistoryEntry[];
  demo?: boolean;
};

export type ApiLead = Omit<Lead, "status" | "selected" | "starred" | "notes" | "followUp" | "value" | "foundAt" | "updatedAt" | "history" | "demo">;

export type Template = { id: string; name: string; body: string };

export type Profile = { name: string; company: string; portfolio: string };

export type Settings = {
  theme: "dark" | "light";
  profile: Profile;
  templates: Template[];
  defaultTemplate: string;
  radius: number;
  depth: number;
  excludeChains: boolean;
  recentPlaces: string[];
};

export type View = "painel" | "busca" | "leads" | "pipeline" | "mapa" | "abordagem" | "ajustes";

export const STAGES: { id: Stage; label: string; hint: string }[] = [
  { id: "novo", label: "Novo", hint: "Acabou de entrar na órbita" },
  { id: "qualificado", label: "Qualificado", hint: "Conferido, vale abordar" },
  { id: "contatado", label: "Contatado", hint: "Primeira mensagem enviada" },
  { id: "negociando", label: "Negociando", hint: "Proposta ou conversa ativa" },
  { id: "fechado", label: "Fechado", hint: "Virou cliente" },
  { id: "perdido", label: "Perdido", hint: "Sem interesse agora" },
];

export const STAGE_LABEL: Record<Stage, string> = Object.fromEntries(STAGES.map((s) => [s.id, s.label])) as Record<Stage, string>;
