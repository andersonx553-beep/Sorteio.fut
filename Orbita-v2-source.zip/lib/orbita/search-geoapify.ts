import { SEGMENT_BY_ID } from "@/lib/orbita/segments";

export class SearchError extends Error {}

/**
 * Busca de oportunidades — Geoapify (dados OpenStreetMap).
 *
 * Fluxo por chamada (1 localidade × 1 segmento × 1 página de até 40 fichas):
 *  1. Geocodifica a localidade (pulado quando o painel reenvia o `center`).
 *  2. Lista os lugares da página pedida (`offset`), dentro do raio escolhido.
 *  3. Lê as tags OSM que já vêm no Places (`datasource.raw`). Só consulta o
 *     Place Details quando elas não vierem — economiza cota e tempo.
 *  4. Descarta quem já tem site próprio e, por padrão, franquias/redes.
 *
 * Nunca passa de 42 subrequisições por chamada (limite de Workers).
 */

const PAGE_SIZE = 40;
const MAX_PAGE = 4;

type Raw = Record<string, unknown>;
type Feature = { properties?: Raw; geometry?: { coordinates?: number[] } };
type Collection = { features?: Feature[]; results?: Raw[] };

const str = (v: unknown) => (typeof v === "string" ? v.trim() : typeof v === "number" ? String(v) : "");
const first = (...values: unknown[]) => values.map(str).find(Boolean) || "";

const SOCIAL_DOMAINS = ["instagram.com", "facebook.com", "fb.com", "fb.me", "tiktok.com", "linkedin.com", "wa.me", "whatsapp.com", "api.whatsapp.com", "linktr.ee", "linkr.bio", "beacons.ai", "ifood.com.br", "goo.gl", "maps.app.goo.gl", "bit.ly"];

function hostOf(value: string): string | null {
  try {
    return new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`).hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return null;
  }
}

function isIndependentWebsite(value: unknown): boolean {
  const text = str(value);
  if (!text) return false;
  const host = hostOf(text);
  if (!host) return true;
  return !SOCIAL_DOMAINS.some((d) => host === d || host.endsWith(`.${d}`));
}

function instagramProfile(value: unknown): string {
  const text = str(value);
  if (!text) return "";
  const match = text.match(/^(?:https?:\/\/)?(?:www\.)?instagram\.com\/([a-zA-Z0-9._]{1,30})(?:\/?(?:\?.*)?)?$/i);
  const handle = match?.[1] || (/^@?[a-zA-Z0-9._]{1,30}$/.test(text) ? text.replace(/^@/, "") : "");
  if (!handle || ["p", "reel", "reels", "stories", "explore", "accounts", "direct"].includes(handle.toLowerCase())) return "";
  return `https://www.instagram.com/${handle}/`;
}

function facebookProfile(value: unknown): string {
  const text = str(value);
  if (!text) return "";
  const host = hostOf(text);
  if (host && /(^|\.)(facebook\.com|fb\.com|fb\.me)$/.test(host)) {
    try {
      const url = new URL(/^https?:\/\//i.test(text) ? text : `https://${text}`);
      return `https://www.facebook.com${url.pathname}${url.search}`;
    } catch {
      return "";
    }
  }
  return "";
}

function firstPhone(value: string): string {
  return value.split(/[;,/]/)[0].trim().slice(0, 40);
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000, toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

async function geoapify(url: URL): Promise<Collection> {
  const response = await fetch(url, { signal: AbortSignal.timeout(18000), cache: "no-store" });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) throw new Error("Chave Geoapify inválida ou sem permissão. Confira sua chave.");
    if (response.status === 429) throw new Error("Limite de consultas da sua chave atingido. Consulte a cota no Geoapify.");
    throw new Error("Serviço de dados indisponível (HTTP " + response.status + "). Tente novamente.");
  }
  return (await response.json()) as Collection;
}

type Analysis =
  | { kind: "site" }
  | { kind: "chain" }
  | {
      kind: "lead";
      phone: string; whatsapp: string; email: string; instagramUrl: string; facebookUrl: string;
      openingHours: string; socialOnly: boolean;
    };

/** Recebe as tags OSM (raw) e/ou as propriedades do Place Details. */
function analyze(tags: Raw, details: Raw, excludeChains: boolean): Analysis {
  const websites = [
    tags.website, tags["contact:website"], tags.url, tags["website:menu"],
    details.website, ...(Array.isArray(details.website_other) ? details.website_other : []),
  ].map(str).filter(Boolean);
  if (websites.some(isIndependentWebsite)) return { kind: "site" };

  const brandDetails = (details.brand_details || {}) as Raw;
  if (excludeChains && (str(tags["brand:wikidata"]) || str(tags["brand:wikipedia"]) || str(brandDetails.wikidata))) return { kind: "chain" };

  const contact = (details.contact || {}) as Raw;
  const social = (details.social_media || {}) as Raw;
  const instagramUrl = [tags["contact:instagram"], tags.instagram, contact.instagram, social.instagram, details.instagram, ...websites]
    .map(instagramProfile).find(Boolean) || "";
  const facebookUrl = [tags["contact:facebook"], tags.facebook, contact.facebook, social.facebook, ...websites]
    .map((v) => facebookProfile(v) || (str(v) && !str(v).includes("/") && !str(v).includes(".") && /^[\w.]{3,60}$/.test(str(v)) ? `https://www.facebook.com/${str(v)}` : ""))
    .find(Boolean) || "";
  const whatsappWebsite = websites.find((w) => /wa\.me|whatsapp\.com/i.test(w)) || "";

  return {
    kind: "lead",
    phone: firstPhone(first(tags.phone, tags["contact:phone"], tags["contact:mobile"], tags.mobile, contact.phone)),
    whatsapp: firstPhone(first(tags["contact:whatsapp"], tags.whatsapp, contact.whatsapp, whatsappWebsite.replace(/\D/g, "").length >= 10 ? whatsappWebsite.replace(/\D/g, "") : "")),
    email: first(tags.email, tags["contact:email"], contact.email).slice(0, 120),
    instagramUrl,
    facebookUrl,
    openingHours: first(tags.opening_hours, details.opening_hours).slice(0, 200),
    socialOnly: websites.length > 0,
  };
}

export async function searchGeoapify(body: Raw) {
  let location: string, segmentId: string, apiKey: string, radius: number, page: number, excludeChains: boolean;
  let center: { lat: number; lon: number; label: string } | null = null;
  try {
    location = str(body.location);
    segmentId = str(body.segment || body.category);
    apiKey = String(body.apiKey || "").trim();
    radius = Math.round(Math.min(15000, Math.max(1000, Number(body.radius) || 6000)));
    page = Math.floor(Math.min(MAX_PAGE, Math.max(0, Number(body.page) || 0)));
    excludeChains = body.excludeChains !== false;
    const c = body.center as Raw | undefined;
    if (c && Number.isFinite(Number(c.lat)) && Number.isFinite(Number(c.lon))) {
      center = { lat: Number(c.lat), lon: Number(c.lon), label: str(c.label).slice(0, 160) || location };
    }
    if (location.length < 3 || location.length > 120 || !SEGMENT_BY_ID[segmentId]) throw new SearchError("Informe uma cidade e um segmento válidos.");
    if (apiKey.length < 15 || apiKey.length > 200) throw new SearchError("Adicione sua chave Geoapify para fazer buscas reais.");
  } catch {
    throw new SearchError("Dados da busca inválidos.");
  }

  const segment = SEGMENT_BY_ID[segmentId];
  try {
    if (!center) {
      const geoUrl = new URL("https://api.geoapify.com/v1/geocode/search");
      geoUrl.searchParams.set("text", location);
      geoUrl.searchParams.set("type", "city");
      geoUrl.searchParams.set("format", "json");
      geoUrl.searchParams.set("limit", "1");
      geoUrl.searchParams.set("lang", "pt");
      geoUrl.searchParams.set("apiKey", apiKey);
      const geo = await geoapify(geoUrl);
      const result = geo.results?.[0];
      const lat = Number(result?.lat), lon = Number(result?.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) throw new SearchError("Cidade não encontrada. Use cidade e país.");
      center = { lat, lon, label: str(result?.formatted) || location };
    }

    const placesUrl = new URL("https://api.geoapify.com/v2/places");
    placesUrl.searchParams.set("categories", segment.key);
    placesUrl.searchParams.set("filter", `circle:${center.lon},${center.lat},${radius}`);
    placesUrl.searchParams.set("bias", `proximity:${center.lon},${center.lat}`);
    placesUrl.searchParams.set("limit", String(PAGE_SIZE));
    placesUrl.searchParams.set("offset", String(page * PAGE_SIZE));
    placesUrl.searchParams.set("lang", "pt");
    placesUrl.searchParams.set("apiKey", apiKey);
    const places = await geoapify(placesUrl);
    const candidates = (places.features || []).filter((f) => typeof f.properties?.name === "string" && typeof f.properties?.place_id === "string");

    // Tags OSM já presentes → análise imediata. Sem tags → Place Details.
    const analyses = new Map<string, { feature: Feature; result: Analysis; details: Raw }>();
    const needDetails: Feature[] = [];
    for (const f of candidates) {
      const raw = ((f.properties?.datasource as Raw | undefined)?.raw || null) as Raw | null;
      if (raw && typeof raw === "object" && Object.keys(raw).length > 2) {
        analyses.set(String(f.properties!.place_id), { feature: f, result: analyze(raw, f.properties || {}, excludeChains), details: f.properties || {} });
      } else needDetails.push(f);
    }

    let detailFailures = 0;
    for (let i = 0; i < needDetails.length; i += 4) {
      const batch = needDetails.slice(i, i + 4);
      const details = await Promise.allSettled(batch.map(async (f) => {
        const url = new URL("https://api.geoapify.com/v2/place-details");
        url.searchParams.set("id", String(f.properties?.place_id));
        url.searchParams.set("lang", "pt");
        url.searchParams.set("apiKey", apiKey);
        const response = await geoapify(url);
        return response.features?.find((item) => item.properties?.feature_type === "details")?.properties;
      }));
      details.forEach((result, n) => {
        const f = batch[n];
        if (result.status === "rejected" || !result.value) { detailFailures++; return; }
        const d = result.value;
        const raw = ((d.datasource as Raw | undefined)?.raw || {}) as Raw;
        analyses.set(String(f.properties!.place_id), { feature: f, result: analyze(raw, d, excludeChains), details: d });
      });
    }

    if (needDetails.length && detailFailures === needDetails.length && analyses.size === 0) {
      throw new Error("Não foi possível verificar os sites dos negócios. Tente novamente.");
    }

    let withSite = 0, chains = 0;
    const leads: Raw[] = [];
    for (const { feature, result, details } of analyses.values()) {
      if (result.kind === "site") { withSite++; continue; }
      if (result.kind === "chain") { chains++; continue; }
      const p = feature.properties || {};
      const lat = Number(p.lat ?? feature.geometry?.coordinates?.[1]);
      const lon = Number(p.lon ?? feature.geometry?.coordinates?.[0]);
      const distance = Number.isFinite(Number(p.distance)) ? Number(p.distance) : Number.isFinite(lat) ? haversine(center.lat, center.lon, lat, lon) : null;
      leads.push({
        id: "geo:" + String(p.place_id),
        name: first(details.name, p.name).slice(0, 160),
        segment: segment.id,
        category: segment.short,
        city: location,
        address: [first(p.street), first(p.housenumber)].filter(Boolean).join(", "),
        suburb: first(p.suburb, p.district, p.quarter).slice(0, 80),
        postcode: first(p.postcode).slice(0, 20),
        phone: result.phone,
        whatsapp: result.whatsapp,
        email: result.email,
        instagramUrl: result.instagramUrl,
        facebookUrl: result.facebookUrl,
        openingHours: result.openingHours,
        socialOnly: result.socialOnly,
        distance: distance === null ? null : Math.round(distance),
        mapsUrl: `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=18/${lat}/${lon}`,
        lat,
        lon,
      });
    }

    return {
      leads,
      location,
      center,
      segment: segment.id,
      page,
      scanned: candidates.length,
      withSite,
      chains,
      detailFailures,
      hasMore: candidates.length === PAGE_SIZE && page < MAX_PAGE,
      limited: candidates.length === PAGE_SIZE,
    };
  } catch (error) {
    throw error instanceof SearchError ? error : new SearchError(error instanceof Error ? error.message : "Falha na consulta de dados.");
  }
}
