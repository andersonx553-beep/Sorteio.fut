import type { Lead, Profile, Stage } from "./types";
import { STAGE_LABEL } from "./types";
import { segmentFromLegacyLabel, SEGMENT_BY_ID } from "./segments";

export function normalizeText(v: string) {
  return v.normalize("NFD").replace(/[̀-ͯ]/g, "").toLocaleLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

export function googleMapsLink(lead: Pick<Lead, "lat" | "lon" | "name" | "address" | "city">) {
  const query = [lead.name, lead.address, lead.city].filter(Boolean).join(", ");
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

export function googleMapsPinLink(lead: Pick<Lead, "lat" | "lon">) {
  return `https://www.google.com/maps/search/?api=1&query=${lead.lat},${lead.lon}`;
}

export function instagramLink(lead: Pick<Lead, "instagramUrl" | "name" | "city">) {
  try {
    const url = new URL(lead.instagramUrl || "");
    if (url.protocol === "https:" && ["instagram.com", "www.instagram.com"].includes(url.hostname)) return { url: url.href, found: true };
  } catch {}
  return { url: `https://www.google.com/search?q=${encodeURIComponent(`site:instagram.com "${lead.name}" "${cityOnly(lead.city)}"`)}`, found: false };
}

export function googleSearchLink(lead: Pick<Lead, "name" | "city">) {
  return `https://www.google.com/search?q=${encodeURIComponent(`"${lead.name}" ${cityOnly(lead.city)}`)}`;
}

export function cityOnly(city: string) {
  return city.split(",")[0].trim();
}

export function instagramHandle(url: string) {
  const m = url.match(/instagram\.com\/([^/?#]+)/i);
  return m ? "@" + m[1] : "";
}

const BR_HINT = /(brasil|brazil|\bbr\b)/i;

/** Número apenas com dígitos, com DDI quando for possível inferir. */
export function phoneDigits(phone: string, city: string): string {
  const raw = phone.trim();
  let digits = raw.replace(/\D/g, "");
  if (!digits) return "";
  if (raw.startsWith("+")) return digits;
  if (digits.startsWith("00")) return digits.slice(2);
  if (BR_HINT.test(city) || /^\(?\d{2}\)?\s?9?\d{4}-?\d{4}$/.test(raw)) {
    if (digits.startsWith("0")) digits = digits.replace(/^0+/, "");
    if (digits.length === 10 || digits.length === 11) return "55" + digits;
  }
  return digits;
}

/** Celular brasileiro (provável WhatsApp): 55 + DDD + 9XXXXXXXX. */
export function isLikelyMobile(lead: Pick<Lead, "phone" | "whatsapp" | "city">) {
  if (lead.whatsapp) return true;
  const d = phoneDigits(lead.phone, lead.city);
  return /^55\d{2}9\d{8}$/.test(d);
}

export function whatsappNumber(lead: Pick<Lead, "phone" | "whatsapp" | "city">) {
  return phoneDigits(lead.whatsapp || lead.phone, lead.city);
}

export function whatsappLink(lead: Pick<Lead, "phone" | "whatsapp" | "city">, text: string) {
  const n = whatsappNumber(lead);
  const q = text ? `?text=${encodeURIComponent(text)}` : "";
  return n ? `https://wa.me/${n}${q}` : `https://wa.me/${q}`;
}

export function fillTemplate(body: string, lead: Lead, profile: Profile) {
  const seg = SEGMENT_BY_ID[lead.segment];
  const map: Record<string, string> = {
    nome: lead.name,
    cidade: cityOnly(lead.city),
    bairro: lead.suburb || cityOnly(lead.city),
    segmento: (seg?.short || lead.category).toLowerCase(),
    instagram: instagramHandle(lead.instagramUrl) || "seu Instagram",
    meu_nome: profile.name || "[seu nome]",
    minha_empresa: profile.company || "[sua empresa]",
    portfolio: profile.portfolio || "[link do portfólio]",
  };
  return body.replace(/\{(\w+)\}/g, (m, k: string) => (k in map ? map[k] : m));
}

export function formatDistance(m: number | null) {
  if (m === null || !Number.isFinite(m)) return "";
  return m < 1000 ? `${Math.round(m / 10) * 10} m` : `${(m / 1000).toFixed(1).replace(".", ",")} km`;
}

export function formatMoney(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
}

export function relativeTime(iso: string) {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "";
  const diff = (Date.now() - t) / 1000;
  const rtf = new Intl.RelativeTimeFormat("pt-BR", { numeric: "auto" });
  if (Math.abs(diff) < 60) return "agora";
  if (Math.abs(diff) < 3600) return rtf.format(-Math.round(diff / 60), "minute");
  if (Math.abs(diff) < 86400) return rtf.format(-Math.round(diff / 3600), "hour");
  if (Math.abs(diff) < 86400 * 30) return rtf.format(-Math.round(diff / 86400), "day");
  return new Date(iso).toLocaleDateString("pt-BR");
}

export function todayISO() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

/** Últimos N dias (YYYY-MM-DD), do mais antigo para hoje. */
export function lastDays(n: number) {
  const now = Date.now();
  return Array.from({ length: n }, (_, i) => new Date(now - (n - 1 - i) * 86400000).toISOString().slice(0, 10));
}

export function followUpState(date: string): "late" | "today" | "soon" | "" {
  if (!date) return "";
  const today = todayISO();
  if (date < today) return "late";
  if (date === today) return "today";
  return "soon";
}

export function formatDateBR(date: string) {
  if (!date) return "";
  const [y, m, d] = date.split("-");
  return `${d}/${m}/${y.slice(2)}`;
}

function csvCell(v: string) {
  const safe = /^[\s﻿]*[=+\-@]/.test(v) ? "'" + v : v;
  return '"' + safe.replaceAll('"', '""') + '"';
}

export function downloadBlob(content: BlobPart[], type: string, filename: string) {
  const a = document.createElement("a");
  const url = URL.createObjectURL(new Blob(content, { type }));
  a.href = url;
  a.download = filename;
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

export function exportCsv(rows: Lead[], scoreOf: (l: Lead) => number) {
  const columns = ["Negócio", "Segmento", "Localidade", "Bairro", "Endereço", "Telefone", "WhatsApp", "E-mail", "Instagram (perfil ou busca)", "Facebook", "Horário", "Score", "Estágio", "Valor estimado", "Follow-up", "Notas", "Google Maps", "Ficha OSM", "Fonte", "Capturado em"];
  const content = [
    columns.join(";"),
    ...rows.map((l) =>
      [
        l.name, l.category, l.city, l.suburb, l.address, l.phone, whatsappNumber(l) ? `https://wa.me/${whatsappNumber(l)}` : "",
        l.email, instagramLink(l).url, l.facebookUrl, l.openingHours, String(scoreOf(l)), STAGE_LABEL[l.status],
        l.value ? String(l.value) : "", l.followUp, l.notes, googleMapsLink(l), l.mapsUrl, "OpenStreetMap contributors (ODbL)", l.foundAt,
      ].map((v) => csvCell(v || "")).join(";"),
    ),
  ].join("\r\n");
  downloadBlob(["﻿", content], "text/csv;charset=utf-8", "orbita-leads-" + todayISO() + ".csv");
}

/** Converte qualquer registro salvo (v1 ou v2) para o formato atual. */
export function migrateLead(input: Record<string, unknown>): Lead | null {
  if (!input || typeof input !== "object" || typeof input.id !== "string" || typeof input.name !== "string") return null;
  const s = (k: string) => (typeof input[k] === "string" ? (input[k] as string) : "");
  const statusMap: Record<string, Stage> = { novo: "novo", revisado: "qualificado", qualificado: "qualificado", contatado: "contatado", negociando: "negociando", fechado: "fechado", perdido: "perdido" };
  const segment = s("segment") && SEGMENT_BY_ID[s("segment")] ? s("segment") : segmentFromLegacyLabel(s("category"));
  const foundAt = s("foundAt") || new Date().toISOString();
  return {
    id: input.id as string,
    name: input.name as string,
    segment,
    category: s("category") || SEGMENT_BY_ID[segment]?.short || "",
    city: s("city"),
    address: s("address"),
    suburb: s("suburb"),
    postcode: s("postcode"),
    phone: s("phone"),
    whatsapp: s("whatsapp"),
    email: s("email"),
    instagramUrl: s("instagramUrl"),
    facebookUrl: s("facebookUrl"),
    openingHours: s("openingHours"),
    socialOnly: input.socialOnly === true,
    distance: typeof input.distance === "number" ? input.distance : null,
    mapsUrl: s("mapsUrl"),
    lat: Number(input.lat),
    lon: Number(input.lon),
    status: statusMap[s("status")] || "novo",
    selected: false,
    starred: input.starred === true,
    notes: s("notes"),
    followUp: s("followUp"),
    value: typeof input.value === "number" ? input.value : 0,
    foundAt,
    updatedAt: s("updatedAt") || foundAt,
    history: Array.isArray(input.history) ? (input.history as Lead["history"]).slice(-60) : [{ at: foundAt, text: "Lead encontrado na busca", kind: "system" }],
    demo: input.demo === true,
  };
}
