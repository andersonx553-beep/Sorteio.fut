import React from "react";
import { createRoot } from "react-dom/client";
import OrbitaApp from "../components/orbita/app";
import "../app/globals.css";

declare global { interface Window { __ORBITA_GITHUB_PAGES__?: boolean } }
window.__ORBITA_GITHUB_PAGES__ = true;

const mount = document.getElementById("root");
if (!mount) throw new Error("Não foi possível abrir o Órbita.");
createRoot(mount).render(<React.StrictMode><OrbitaApp /></React.StrictMode>);
