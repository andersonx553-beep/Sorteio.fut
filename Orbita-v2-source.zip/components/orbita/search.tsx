"use client";
import { useMemo, useRef, useState } from "react";
import { ArrowUpRight, Check, KeyRound, MapPin, Plus, Radar, Square, X, Zap } from "lucide-react";
import { SEGMENTS, SEGMENT_GROUPS, type SegmentGroup } from "@/lib/orbita/segments";
import { cityOnly } from "@/lib/orbita/utils";
import { IS_PREVIEW, useOrbita, type RadarBlip } from "./store";
import { SegmentIcon } from "./icons";
import { Switch } from "./bits";

const SUGGESTED = ["Fortaleza, Brasil", "Eusébio, Brasil", "Caucaia, Brasil", "Maracanaú, Brasil", "Aquiraz, Brasil", "Sobral, Brasil", "Juazeiro do Norte, Brasil", "Recife, Brasil"];
const MAX_PLACES = 10;
const MAX_JOBS = 40;

export function SearchView() {
  const { settings, updateSettings, apiKey, setApiKey, search, startSearch, cancelSearch, leads } = useOrbita();
  const [places, setPlaces] = useState<string[]>(settings.recentPlaces.slice(0, 1).length ? settings.recentPlaces.slice(0, 1) : ["Fortaleza, Brasil"]);
  const [draft, setDraft] = useState("");
  const [segments, setSegments] = useState<string[]>(["restaurant"]);
  const [group, setGroup] = useState<SegmentGroup | "Todos">("Todos");
  const [radius, setRadius] = useState(settings.radius);
  const [depth, setDepth] = useState(settings.depth);
  const [excludeChains, setExcludeChains] = useState(settings.excludeChains);
  const [keyDraft, setKeyDraft] = useState("");
  const [editingKey, setEditingKey] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const addPlaces = (text: string) => {
    const items = text.split(/[\n;]+/).map((x) => x.trim()).filter((x) => x.length >= 3);
    if (!items.length) return;
    setPlaces((old) => [...new Set([...old, ...items])].slice(0, MAX_PLACES));
    setDraft("");
  };
  const toggleSeg = (id: string) => setSegments((old) => (old.includes(id) ? old.filter((x) => x !== id) : [...old, id]));
  const visible = SEGMENTS.filter((s) => group === "Todos" || s.group === group);
  const jobs = places.length * segments.length;
  const maxFichas = jobs * depth * 40;
  const tooMany = jobs > MAX_JOBS;

  const canRun = places.length > 0 && segments.length > 0 && (apiKey.length >= 15 || IS_PREVIEW) && !tooMany && !search.running;

  function run() {
    if (!canRun) return;
    updateSettings({ radius, depth, excludeChains, recentPlaces: [...new Set([...places, ...settings.recentPlaces])].slice(0, 8) });
    void startSearch({ places, segments, radius, depth, excludeChains });
  }

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <span className="eyebrow">Radar de busca</span>
          <h1>Encontre quem <em>precisa de um site.</em></h1>
          <p>Varra cidades inteiras por segmento. O Órbita lê cada ficha do OpenStreetMap, descarta quem já tem site e redes/franquias, e pontua o que sobrar.</p>
        </div>
      </div>

      <div className="search-grid">
        <section className="panel fade-up" aria-label="Configurar varredura">
          <div className="block">
            <div className="step"><span className="step-n">01</span><h3>Onde procurar</h3><span>{places.length}/{MAX_PLACES} localidades</span></div>
            <div className="places-box" onClick={() => inputRef.current?.focus()}>
              {places.map((p) => (
                <span className="place-chip" key={p}>
                  <MapPin />{p}
                  <button type="button" aria-label={`Remover ${p}`} onClick={(e) => { e.stopPropagation(); setPlaces((o) => o.filter((x) => x !== p)); }}><X /></button>
                </span>
              ))}
              <input
                ref={inputRef}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if ((e.key === "Enter" || e.key === ";") && draft.trim()) { e.preventDefault(); addPlaces(draft); }
                  if (e.key === "Backspace" && !draft && places.length) setPlaces((o) => o.slice(0, -1));
                }}
                onPaste={(e) => { const t = e.clipboardData.getData("text"); if (/[\n;]/.test(t)) { e.preventDefault(); addPlaces(t); } }}
                onBlur={() => draft.trim() && addPlaces(draft)}
                placeholder={places.length ? "Adicionar outra cidade…" : "Cidade, País — Enter para adicionar"}
                aria-label="Adicionar localidade"
                disabled={places.length >= MAX_PLACES}
              />
            </div>
            <div className="suggest">
              <span>Sugestões</span>
              {[...new Set([...settings.recentPlaces, ...SUGGESTED])].filter((s) => !places.includes(s)).slice(0, 6).map((s) => (
                <button type="button" className="chip" key={s} onClick={() => addPlaces(s)}><Plus />{cityOnly(s)}</button>
              ))}
            </div>
          </div>

          <div className="block">
            <div className="step"><span className="step-n">02</span><h3>Quais segmentos</h3><span>{segments.length} {segments.length === 1 ? "selecionado" : "selecionados"}</span></div>
            <div className="seg-toolbar">
              {(["Todos", ...SEGMENT_GROUPS] as const).map((g) => (
                <button type="button" key={g} className="chip" aria-pressed={group === g} onClick={() => setGroup(g)}>{g}</button>
              ))}
            </div>
            <div className="seg-grid">
              {visible.map((s) => (
                <button type="button" key={s.id} className="seg-card" aria-pressed={segments.includes(s.id)} onClick={() => toggleSeg(s.id)} title={`Potencial de ticket: ${["", "entrada", "médio", "alto"][s.tier]}`}>
                  <span className="si"><SegmentIcon id={s.id} /></span>
                  <span>{s.label}</span>
                  <span className="tier" aria-hidden="true">{[1, 2, 3].map((t) => <i key={t} className={t <= s.tier ? "on" : ""} />)}</span>
                </button>
              ))}
            </div>
            <div className="suggest">
              <span>Atalhos</span>
              <button type="button" className="chip" onClick={() => setSegments(SEGMENTS.filter((s) => s.tier === 3).map((s) => s.id))}><Zap />Ticket alto</button>
              <button type="button" className="chip" onClick={() => setSegments(visible.map((s) => s.id))}><Check />Marcar visíveis</button>
              {segments.length > 0 && <button type="button" className="chip" onClick={() => setSegments([])}><X />Limpar</button>}
            </div>
          </div>

          <div className="block">
            <div className="step"><span className="step-n">03</span><h3>Alcance da varredura</h3></div>
            <div className="params">
              <div>
                <div className="label">Raio a partir do centro <span>1 a 15 km</span></div>
                <div className="range-row">
                  <input className="range" type="range" min={1000} max={15000} step={500} value={radius} onChange={(e) => setRadius(Number(e.target.value))} style={{ ["--p" as string]: `${((radius - 1000) / 14000) * 100}%` }} aria-label="Raio da busca" />
                  <span className="range-val">{(radius / 1000).toLocaleString("pt-BR")} km</span>
                </div>
              </div>
              <div>
                <div className="label">Profundidade <span>fichas por segmento</span></div>
                <div className="seg-tabs" role="group" aria-label="Profundidade">
                  {[1, 2, 3].map((n) => <button type="button" key={n} aria-pressed={depth === n} onClick={() => setDepth(n)}>{n * 40}</button>)}
                </div>
              </div>
            </div>
            <label className="opt-row" style={{ marginTop: 18 }}>
              <span className="grow"><strong>Ignorar redes e franquias</strong><small>Remove marcas conhecidas (com cadastro de marca no OSM) — elas não compram site de freelancer.</small></span>
              <Switch checked={excludeChains} onChange={setExcludeChains} label="Ignorar redes e franquias" />
            </label>
          </div>

          <div className="block">
            {IS_PREVIEW ? (
              <div className="key-box">
                <Radar size={18} style={{ color: "var(--accent)" }} />
                <div className="grow"><strong>Modo prévia</strong><small>As varreduras aqui são simuladas com negócios fictícios. No app publicado, elas usam sua chave Geoapify e dados reais do OpenStreetMap.</small></div>
              </div>
            ) : apiKey && !editingKey ? (
              <div className="key-box ok">
                <KeyRound size={18} style={{ color: "var(--green)" }} />
                <div className="grow"><strong>Geoapify conectado</strong><small className="mono">•••• •••• {apiKey.slice(-4)} · salvo só neste navegador</small></div>
                <button className="btn btn-sm" onClick={() => { setEditingKey(true); setKeyDraft(""); }}>Trocar</button>
              </div>
            ) : (
              <div className="key-box">
                <KeyRound size={18} style={{ color: "var(--accent)" }} />
                <div className="grow"><strong>Conecte sua chave Geoapify</strong><small>Grátis em <a href="https://myprojects.geoapify.com/" target="_blank" rel="noopener noreferrer">Geoapify MyProjects <ArrowUpRight size={11} style={{ display: "inline" }} /></a>. Fica salva só neste navegador.</small></div>
                <input className="input mono" type="password" autoComplete="off" placeholder="Cole a chave aqui" value={keyDraft} onChange={(e) => setKeyDraft(e.target.value.trim())} onKeyDown={(e) => { if (e.key === "Enter" && keyDraft.length >= 15) { setApiKey(keyDraft); setEditingKey(false); } }} aria-label="Chave de API Geoapify" />
                <button className="btn btn-sm btn-primary" disabled={keyDraft.length < 15} onClick={() => { setApiKey(keyDraft); setEditingKey(false); }}>Salvar</button>
              </div>
            )}
          </div>

          <div className="launch">
            <div className="grow">
              <strong>{places.length} × {segments.length} = {jobs} {jobs === 1 ? "varredura" : "varreduras"}</strong>
              <small>{tooMany ? `Limite de ${MAX_JOBS} combinações por lote — reduza cidades ou segmentos.` : <>Até <span className="cost">{maxFichas.toLocaleString("pt-BR")}</span> fichas analisadas · raio de {(radius / 1000).toLocaleString("pt-BR")} km</>}</small>
            </div>
            {search.running ? (
              <button className="btn btn-lg btn-danger" onClick={cancelSearch}><Square /> Interromper</button>
            ) : (
              <button className="btn btn-primary btn-lg" disabled={!canRun} onClick={run}><Radar /> Iniciar varredura</button>
            )}
          </div>
        </section>

        <RadarPanel leadsCount={leads.length} />
      </div>
    </>
  );
}

function RadarPanel({ leadsCount }: { leadsCount: number }) {
  const { search, leads, setView } = useOrbita();

  // Sem varredura nesta sessão: mostra a carteira atual ao redor do centro médio da cidade mais comum.
  const idleBlips = useMemo<{ blips: RadarBlip[]; radius: number }>(() => {
    if (!leads.length) return { blips: [], radius: 6000 };
    const byCity = new Map<string, typeof leads>();
    leads.forEach((l) => { if (Number.isFinite(l.lat)) byCity.set(l.city, [...(byCity.get(l.city) || []), l]); });
    const group = [...byCity.values()].sort((a, b) => b.length - a.length)[0] || [];
    if (!group.length) return { blips: [], radius: 6000 };
    const c = { lat: group.reduce((s, l) => s + l.lat, 0) / group.length, lon: group.reduce((s, l) => s + l.lon, 0) / group.length };
    const blips = group.slice(0, 300).map((l) => {
      const dy = (l.lat - c.lat) * 111320, dx = (l.lon - c.lon) * 111320 * Math.cos((c.lat * Math.PI) / 180);
      return { id: l.id, bearing: Math.atan2(dy, dx), dist: Math.hypot(dx, dy), heat: (l.phone ? 1 : 0) + (l.instagramUrl ? 1 : 0) };
    });
    const radius = Math.max(2000, Math.ceil(Math.max(...blips.map((b) => b.dist)) / 1000) * 1000);
    return { blips, radius };
  }, [leads]);

  const live = search.running || search.blips.length > 0;
  const blips = live ? search.blips : idleBlips.blips;
  const radius = live ? search.radius : idleBlips.radius;
  const pct = search.total ? (search.done / search.total) * 100 : 0;

  return (
    <aside className={`panel radar-panel fade-up ${search.running ? "" : "radar-idle"}`} style={{ animationDelay: ".1s" }} aria-label="Radar">
      <div className="panel-head">
        <div className="ico-box" style={{ background: "var(--cyan-soft)", color: "var(--cyan)", borderColor: "color-mix(in srgb, var(--cyan) 30%, transparent)" }}><Radar /></div>
        <div><h3>Radar</h3><p>{search.running ? search.current || "Preparando…" : live ? "Resultado da última varredura" : leadsCount ? "Sua carteira atual" : "Aguardando a primeira varredura"}</p></div>
        <div className="spacer" />
        <span className="tag" style={search.running ? { color: "var(--green)", borderColor: "color-mix(in srgb, var(--green) 35%, transparent)" } : undefined}>
          <span className={`dot ${search.running ? "" : "off"}`} />{search.running ? "Ao vivo" : "Em espera"}
        </span>
      </div>
      {search.running && <div className="progress"><i style={{ width: `${Math.max(3, pct)}%` }} /></div>}
      <div style={{ padding: "8px 18px 14px" }}>
        <div className="radar-wrap">
          <svg viewBox="0 0 400 400" role="img" aria-label={`${blips.length} negócios no radar`}>
            <defs>
              <radialGradient id="rd-bg" cx="50%" cy="50%" r="50%">
                <stop offset="0" stopColor="var(--cyan)" stopOpacity=".10" />
                <stop offset="1" stopColor="var(--cyan)" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="rd-sweep" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="var(--cyan)" stopOpacity="0" />
                <stop offset="1" stopColor="var(--cyan)" stopOpacity=".35" />
              </linearGradient>
            </defs>
            <circle cx="200" cy="200" r="190" fill="url(#rd-bg)" />
            {[0.25, 0.5, 0.75, 1].map((f) => (
              <g key={f}>
                <circle cx="200" cy="200" r={180 * f} fill="none" stroke="var(--cyan)" strokeOpacity={f === 1 ? 0.35 : 0.14} strokeDasharray={f === 1 ? undefined : "2 5"} />
                <text x={200 + 180 * f * 0.707 + 4} y={200 - 180 * f * 0.707 - 4} fill="var(--text-3)" fontSize="9.5" fontFamily="JetBrains Mono, monospace">{((radius * f) / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} km</text>
              </g>
            ))}
            <line x1="20" y1="200" x2="380" y2="200" stroke="var(--cyan)" strokeOpacity=".12" />
            <line x1="200" y1="20" x2="200" y2="380" stroke="var(--cyan)" strokeOpacity=".12" />
            {["N", "L", "S", "O"].map((t, i) => (
              <text key={t} x={200 + [0, 194, 0, -194][i]} y={200 + [-192, 0, 196, 0][i]} textAnchor="middle" dominantBaseline="middle" fill="var(--text-3)" fontSize="10" fontWeight="600" fontFamily="JetBrains Mono, monospace">{t}</text>
            ))}
            <g className="radar-sweep">
              <path d="M200 200 L380 200 A180 180 0 0 0 355.9 110 Z" fill="url(#rd-sweep)" />
              <line x1="200" y1="200" x2="380" y2="200" stroke="var(--cyan)" strokeOpacity=".8" strokeWidth="1.5" />
            </g>
            {blips.map((b, i) => {
              const r = Math.min(1, b.dist / radius) * 180;
              const x = 200 + Math.cos(b.bearing) * r, y = 200 - Math.sin(b.bearing) * r;
              const color = b.heat >= 2 ? "var(--orange)" : b.heat === 1 ? "var(--accent)" : "var(--cyan)";
              return (
                <g key={b.id} className="blip" style={{ animationDelay: `${live ? 0 : Math.min(i * 8, 900)}ms` }}>
                  <circle cx={x} cy={y} r={b.heat >= 2 ? 7 : 5.5} fill={color} opacity=".18" />
                  <circle cx={x} cy={y} r={b.heat >= 2 ? 3.4 : 2.6} fill={color} />
                </g>
              );
            })}
            <circle className="radar-center" cx="200" cy="200" r="5" fill="var(--accent)" />
            <circle cx="200" cy="200" r="11" fill="none" stroke="var(--accent)" strokeOpacity=".4" />
          </svg>
        </div>
        <div className="legend" style={{ justifyContent: "center", paddingTop: 4 }}>
          <span><i style={{ ["--c" as string]: "var(--orange)" }} />Telefone + Instagram</span>
          <span><i style={{ ["--c" as string]: "var(--accent)" }} />Um canal</span>
          <span><i style={{ ["--c" as string]: "var(--cyan)" }} />Só endereço</span>
        </div>
      </div>
      <div className="radar-stats">
        <div><b className="num">{live ? search.scanned : "—"}</b><span>Analisados</span></div>
        <div><b className="num">{live ? search.withSite : "—"}</b><span>Já têm site</span></div>
        <div><b className="num">{live ? search.chains : "—"}</b><span>Redes</span></div>
        <div className="hi"><b className="num">{live ? search.added : blips.length}</b><span>{live ? "Oportunidades" : "Na carteira"}</span></div>
      </div>
      {search.log.length > 0 && (
        <div className="console" aria-live="polite">
          {search.log.map((l) => (
            <p key={l.id}><time>{new Date(l.at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</time><span className={l.kind}>{l.text}</span></p>
          ))}
          {search.running && <p><time>&nbsp;</time><span className="cursor" /></p>}
        </div>
      )}
      {!search.running && search.added > 0 && (
        <div style={{ padding: 14, borderTop: "1px solid var(--line)" }}>
          <button className="btn btn-primary" style={{ width: "100%" }} onClick={() => setView("leads")}>Ver {search.added} {search.added === 1 ? "oportunidade" : "oportunidades"} <ArrowUpRight /></button>
        </div>
      )}
    </aside>
  );
}
