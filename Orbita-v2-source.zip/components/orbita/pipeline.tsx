"use client";
import { useMemo, useState } from "react";
import { Radar, Search, Sparkles } from "lucide-react";
import type { Stage } from "@/lib/orbita/types";
import { STAGES } from "@/lib/orbita/types";
import { leadScore } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, followUpState, formatDateBR, formatMoney, isLikelyMobile, normalizeText } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { InstagramIcon, WhatsAppIcon } from "./icons";
import { OrbitArt, ScoreBadge, STAGE_COLOR } from "./bits";
import { Phone } from "lucide-react";

export function PipelineView() {
  const { leads, setStage, openLead, setView, loadDemo } = useOrbita();
  const [dragId, setDragId] = useState<string | null>(null);
  const [over, setOver] = useState<Stage | null>(null);
  const [query, setQuery] = useState("");
  const [hideLost, setHideLost] = useState(false);

  const cols = useMemo(() => {
    const q = normalizeText(query);
    const map = new Map<Stage, { id: string; s: number }[]>(STAGES.map((s) => [s.id, []]));
    for (const l of leads) {
      if (q && !normalizeText(`${l.name} ${l.suburb} ${l.city} ${l.category}`).includes(q)) continue;
      map.get(l.status)!.push({ id: l.id, s: leadScore(l) });
    }
    map.forEach((arr) => arr.sort((a, b) => b.s - a.s));
    return map;
  }, [leads, query]);
  const byId = useMemo(() => new Map(leads.map((l) => [l.id, l])), [leads]);

  const drop = (stage: Stage) => {
    if (dragId) setStage([dragId], stage);
    setDragId(null);
    setOver(null);
  };

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <span className="eyebrow">Pipeline</span>
          <h1>Do primeiro “oi” ao <em>site no ar.</em></h1>
          <p>Arraste os cartões entre as colunas para atualizar o estágio. Cada movimento fica registrado no histórico do lead.</p>
        </div>
        <div className="head-actions">
          <div className="input-wrap" style={{ width: 240 }}><Search /><input className="input" placeholder="Filtrar cartões…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Filtrar cartões" /></div>
          <button className="chip" aria-pressed={hideLost} onClick={() => setHideLost((v) => !v)} style={{ height: 40 }}>Ocultar perdidos</button>
        </div>
      </div>

      {!leads.length ? (
        <section className="panel"><div className="empty"><OrbitArt className="empty-art" /><h3>Pipeline vazio</h3><p>Os negócios encontrados nas varreduras entram aqui como “Novo”.</p><div className="row"><button className="btn btn-primary" onClick={() => setView("busca")}><Radar /> Nova varredura</button><button className="btn" onClick={loadDemo}><Sparkles /> Carregar exemplo</button></div></div></section>
      ) : (
        <div className="board fade-up">
          {STAGES.filter((s) => !(hideLost && s.id === "perdido")).map((st) => {
            const items = cols.get(st.id) || [];
            const sum = items.reduce((acc, it) => acc + (byId.get(it.id)?.value || 0), 0);
            return (
              <section
                key={st.id}
                className={`kcol ${over === st.id ? "over" : ""}`}
                onDragOver={(e) => { e.preventDefault(); if (over !== st.id) setOver(st.id); }}
                onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setOver(null); }}
                onDrop={(e) => { e.preventDefault(); drop(st.id); }}
                aria-label={`${st.label}: ${items.length}`}
              >
                <header className="kcol-head" style={{ color: STAGE_COLOR[st.id] }}>
                  <i />
                  <h3 style={{ color: "var(--text)" }}>{st.label}</h3>
                  <span className="n">{items.length}</span>
                  {sum > 0 && <span className="sum">{formatMoney(sum)}</span>}
                </header>
                <div className="kcol-body">
                  {items.length === 0 && <div className="kcol-empty">{st.hint}</div>}
                  {items.slice(0, 80).map(({ id, s }) => {
                    const l = byId.get(id)!;
                    const fu = followUpState(l.followUp);
                    return (
                      <button
                        key={id}
                        className={`kcard ${dragId === id ? "dragging" : ""}`}
                        draggable
                        onDragStart={(e) => { setDragId(id); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", id); }}
                        onDragEnd={() => { setDragId(null); setOver(null); }}
                        onClick={() => openLead(id)}
                      >
                        <span className="kc-score"><ScoreBadge score={s} /></span>
                        <strong>{l.name}</strong>
                        <small>{SEGMENT_BY_ID[l.segment]?.short} · {l.suburb || cityOnly(l.city)}</small>
                        <div className="kc-foot">
                          <span className={`cdot ${l.phone ? "on" : ""}`}><Phone /></span>
                          <span className={`cdot wa ${isLikelyMobile(l) ? "on" : ""}`}><WhatsAppIcon /></span>
                          <span className={`cdot ig ${l.instagramUrl ? "on" : ""}`}><InstagramIcon /></span>
                          {l.followUp && fu && <span className={`due ${fu}`} style={{ marginLeft: 4 }}>{fu === "late" ? "Atrasado" : fu === "today" ? "Hoje" : formatDateBR(l.followUp)}</span>}
                          {l.value > 0 && <span className="val">{formatMoney(l.value)}</span>}
                        </div>
                      </button>
                    );
                  })}
                  {items.length > 80 && <div className="hint" style={{ textAlign: "center" }}>+{items.length - 80} na lista de leads</div>}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}
