"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ExternalLink, Maximize2, Minus, Plus, Radar, Sparkles, X } from "lucide-react";
import type { Lead, Stage } from "@/lib/orbita/types";
import { STAGES } from "@/lib/orbita/types";
import { leadScore, heatOf } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, googleMapsLink } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { OrbitArt, ScoreBadge, STAGE_COLOR, StagePill } from "./bits";

/* Mapa leve, sem biblioteca: projeção Web Mercator + tiles raster da CARTO (dados OSM). */
const TILE = 256;
const MIN_Z = 3, MAX_Z = 18;
const worldSize = (z: number) => TILE * 2 ** z;
function project(lat: number, lon: number, z: number) {
  const s = Math.sin((Math.max(-85, Math.min(85, lat)) * Math.PI) / 180);
  const W = worldSize(z);
  return { x: ((lon + 180) / 360) * W, y: (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * W };
}
function unproject(x: number, y: number, z: number) {
  const W = worldSize(z);
  const lon = (x / W) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / W;
  return { lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lon };
}

type ColorMode = "stage" | "heat";
const HEAT_COLOR = { quente: "var(--orange)", morno: "var(--accent)", frio: "var(--blue)" } as const;

export function MapView() {
  const { leads, settings, openLead, setView, loadDemo } = useOrbita();
  const ref = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [view, setMapView] = useState<{ lat: number; lon: number; z: number } | null>(null);
  const [mode, setMode] = useState<ColorMode>("stage");
  const [hidden, setHidden] = useState<Set<Stage>>(new Set());
  const [active, setActive] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const drag = useRef<{ x: number; y: number; cx: number; cy: number; moved: boolean } | null>(null);
  const wheelAcc = useRef(0);

  const points = useMemo(() => leads.filter((l) => Number.isFinite(l.lat) && Number.isFinite(l.lon) && !hidden.has(l.status)), [leads, hidden]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, [leads.length]);

  const fit = useCallback((list: Lead[]) => {
    if (!list.length) { setMapView({ lat: -3.7319, lon: -38.5267, z: 12 }); return; }
    const lats = list.map((l) => l.lat), lons = list.map((l) => l.lon);
    const minLat = Math.min(...lats), maxLat = Math.max(...lats), minLon = Math.min(...lons), maxLon = Math.max(...lons);
    let z = MAX_Z - 2;
    for (; z > MIN_Z; z--) {
      const a = project(maxLat, minLon, z), b = project(minLat, maxLon, z);
      if (b.x - a.x < size.w - 120 && b.y - a.y < size.h - 140) break;
    }
    setMapView({ lat: (minLat + maxLat) / 2, lon: (minLon + maxLon) / 2, z: Math.min(z, 16) });
  }, [size.w, size.h]);

  // Enquadra os leads na primeira renderização com tamanho real.
  const fitted = useRef(false);
  useEffect(() => {
    if (fitted.current || size.w < 50) return;
    fitted.current = true;
    fit(points);
  }, [fit, points, size.w]);

  const v = view || { lat: -3.7319, lon: -38.5267, z: 12 };
  const c = project(v.lat, v.lon, v.z);
  const originX = c.x - size.w / 2, originY = c.y - size.h / 2;

  const tiles = useMemo(() => {
    const out: { key: string; src: string; left: number; top: number }[] = [];
    const n = 2 ** v.z;
    const x0 = Math.floor(originX / TILE), x1 = Math.floor((originX + size.w) / TILE);
    const y0 = Math.max(0, Math.floor(originY / TILE)), y1 = Math.min(n - 1, Math.floor((originY + size.h) / TILE));
    const style = settings.theme === "dark" ? "dark_all" : "rastertiles/voyager";
    const dpr = typeof window !== "undefined" && window.devicePixelRatio > 1 ? "@2x" : "";
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) {
      const wx = ((x % n) + n) % n;
      const sub = "abcd"[(wx + y) % 4];
      out.push({ key: `${v.z}/${x}/${y}`, src: `https://${sub}.basemaps.cartocdn.com/${style}/${v.z}/${wx}/${y}${dpr}.png`, left: x * TILE - originX, top: y * TILE - originY });
    }
    return out;
  }, [v.z, originX, originY, size.w, size.h, settings.theme]);

  // Agrupa marcadores próximos em zooms baixos.
  const markers = useMemo(() => {
    const cell = v.z >= 15 ? 0 : 42;
    const items = points.map((l) => { const p = project(l.lat, l.lon, v.z); return { l, x: p.x - originX, y: p.y - originY, s: leadScore(l) }; })
      .filter((m) => m.x > -40 && m.y > -40 && m.x < size.w + 40 && m.y < size.h + 40);
    if (!cell) return items.map((m) => ({ ...m, n: 1, ids: [m.l.id] }));
    const grid = new Map<string, typeof items>();
    for (const m of items) {
      const k = `${Math.floor((m.x + originX) / cell)}:${Math.floor((m.y + originY) / cell)}`;
      grid.set(k, [...(grid.get(k) || []), m]);
    }
    return [...grid.values()].map((g) => {
      const best = g.reduce((a, b) => (b.s > a.s ? b : a));
      return { ...best, x: g.reduce((a, m) => a + m.x, 0) / g.length, y: g.reduce((a, m) => a + m.y, 0) / g.length, n: g.length, ids: g.map((m) => m.l.id) };
    });
  }, [points, v.z, originX, originY, size.w, size.h]);

  const zoomAt = (dz: number, px = size.w / 2, py = size.h / 2) => {
    const z = Math.max(MIN_Z, Math.min(MAX_Z, v.z + dz));
    if (z === v.z) return;
    const before = unproject(originX + px, originY + py, v.z);
    const p = project(before.lat, before.lon, z);
    const cc = unproject(p.x - px + size.w / 2, p.y - py + size.h / 2, z);
    setMapView({ lat: cc.lat, lon: cc.lon, z });
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest(".marker, .map-card")) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { x: e.clientX, y: e.clientY, cx: c.x, cy: c.y, moved: false };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) < 3) return;
    if (!d.moved) { d.moved = true; setDragging(true); }
    const p = unproject(d.cx - dx, d.cy - dy, v.z);
    setMapView({ lat: p.lat, lon: p.lon, z: v.z });
  };
  const onPointerUp = () => {
    if (drag.current && !drag.current.moved) setActive(null);
    drag.current = null;
    setDragging(false);
  };
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      wheelAcc.current += e.deltaY;
      if (Math.abs(wheelAcc.current) < 60) return;
      const rect = el.getBoundingClientRect();
      const dz = wheelAcc.current < 0 ? 1 : -1;
      wheelAcc.current = 0;
      zoomRef.current(dz, e.clientX - rect.left, e.clientY - rect.top);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [leads.length]);
  const zoomRef = useRef(zoomAt);
  useEffect(() => { zoomRef.current = zoomAt; });

  const activeLead = active ? leads.find((l) => l.id === active) : null;
  const activePos = activeLead ? (() => { const p = project(activeLead.lat, activeLead.lon, v.z); return { x: p.x - originX, y: p.y - originY }; })() : null;
  const colorOf = (l: Lead, s: number) => (mode === "stage" ? STAGE_COLOR[l.status] : HEAT_COLOR[heatOf(s)]);

  if (!leads.length) {
    return (
      <>
        <MapHead />
        <section className="panel"><div className="empty"><OrbitArt className="empty-art" /><h3>Nada para mostrar no mapa</h3><p>Depois da primeira varredura, cada negócio aparece aqui na posição real.</p><div className="row"><button className="btn btn-primary" onClick={() => setView("busca")}><Radar /> Nova varredura</button><button className="btn" onClick={loadDemo}><Sparkles /> Carregar exemplo</button></div></div></section>
      </>
    );
  }

  return (
    <>
      <MapHead />
      <div
        className="map-shell fade-up"
        ref={ref}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); zoomAt(1, e.clientX - r.left, e.clientY - r.top); }}
        role="application"
        aria-label="Mapa de leads. Arraste para mover, role para aproximar."
      >
        <div className={`map-tiles ${dragging ? "dragging" : ""}`}>
          {/* eslint-disable-next-line @next/next/no-img-element -- tiles de mapa: imagens externas simples, sem otimização */}
          {tiles.map((t) => <img key={t.key} src={t.src} alt="" style={{ left: t.left, top: t.top }} draggable={false} onError={(e) => { e.currentTarget.style.visibility = "hidden"; }} />)}
        </div>
        {markers.map((m) => (
          <button
            key={m.ids[0] + m.n}
            className={`marker ${m.n > 1 ? "cluster" : ""} ${active === m.l.id ? "active" : ""}`}
            style={{ left: m.x, top: m.y, ["--c" as string]: colorOf(m.l, m.s) }}
            onClick={(e) => {
              e.stopPropagation();
              if (m.n > 1) zoomAt(2, m.x, m.y);
              else setActive(m.l.id);
            }}
            aria-label={m.n > 1 ? `${m.n} negócios — aproximar` : m.l.name}
            title={m.n > 1 ? `${m.n} negócios` : m.l.name}
          >
            {m.n > 1 ? m.n : null}
          </button>
        ))}
        {activeLead && activePos && (
          <div className="map-card glass" style={{ left: activePos.x, top: activePos.y }} onPointerDown={(e) => e.stopPropagation()}>
            <button className="x" onClick={() => setActive(null)} aria-label="Fechar"><X size={16} /></button>
            <strong>{activeLead.name}</strong>
            <small>{SEGMENT_BY_ID[activeLead.segment]?.short} · {activeLead.suburb || cityOnly(activeLead.city)}</small>
            <div className="row" style={{ alignItems: "center" }}><StagePill stage={activeLead.status} /><ScoreBadge score={leadScore(activeLead)} /></div>
            <div className="row">
              <button className="btn btn-sm btn-primary" style={{ flex: 1 }} onClick={() => openLead(activeLead.id)}>Abrir ficha</button>
              <a className="btn btn-sm" href={googleMapsLink(activeLead)} target="_blank" rel="noopener noreferrer"><ExternalLink /> Google</a>
            </div>
          </div>
        )}

        <div className="map-ui tl">
          <div className="glass seg-tabs" style={{ borderRadius: 12 }}>
            <button aria-pressed={mode === "stage"} onClick={() => setMode("stage")}>Por estágio</button>
            <button aria-pressed={mode === "heat"} onClick={() => setMode("heat")}>Por score</button>
          </div>
          <div className="glass legend">
            {mode === "stage"
              ? STAGES.map((s) => (
                  <button key={s.id} style={{ display: "inline-flex", alignItems: "center", gap: 6, opacity: hidden.has(s.id) ? 0.35 : 1 }} onClick={() => setHidden((h) => { const n = new Set(h); if (n.has(s.id)) n.delete(s.id); else n.add(s.id); return n; })} aria-pressed={!hidden.has(s.id)}>
                    <i style={{ width: 9, height: 9, borderRadius: "50%", background: STAGE_COLOR[s.id] }} />{s.label}
                  </button>
                ))
              : (["quente", "morno", "frio"] as const).map((h) => <span key={h}><i style={{ ["--c" as string]: HEAT_COLOR[h] }} />{h[0].toUpperCase() + h.slice(1)}</span>)}
          </div>
        </div>
        <div className="map-ui tr glass" style={{ padding: 4 }}>
          <button className="map-btn btn-ghost btn" onClick={() => zoomAt(1)} aria-label="Aproximar"><Plus /></button>
          <button className="map-btn btn-ghost btn" onClick={() => zoomAt(-1)} aria-label="Afastar"><Minus /></button>
          <button className="map-btn btn-ghost btn" onClick={() => fit(points)} aria-label="Enquadrar todos"><Maximize2 /></button>
        </div>
        <div className="map-ui bl glass" style={{ padding: "8px 12px", fontSize: 12 }}>
          <b className="num">{points.length}</b> <span className="muted">negócios no mapa · zoom {v.z}</span>
        </div>
        <div className="map-ui br">© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> · © <a href="https://carto.com/attributions" target="_blank" rel="noopener noreferrer">CARTO</a></div>
      </div>
    </>
  );
}

function MapHead() {
  return (
    <div className="page-head fade-up">
      <div>
        <span className="eyebrow">Mapa</span>
        <h1>Sua carteira, <em>no território.</em></h1>
        <p>Veja onde as oportunidades se concentram e planeje visitas por bairro. Clique em um ponto para abrir o negócio.</p>
      </div>
    </div>
  );
}
