"use client";
import { useEffect, useMemo } from "react";
import { Toaster } from "sonner";
import { KanbanSquare, LayoutDashboard, Layers3, Map as MapIcon, MessageSquareText, Moon, Radar, Search, Settings, Sun } from "lucide-react";
import type { View } from "@/lib/orbita/types";
import { leadScore, heatOf } from "@/lib/orbita/score";
import { IS_PREVIEW, OrbitaProvider, useOrbita } from "./store";
import { Logo } from "./icons";
import { Dashboard } from "./dashboard";
import { SearchView } from "./search";
import { LeadsView } from "./leads";
import { PipelineView } from "./pipeline";
import { MapView } from "./map-view";
import { OutreachView } from "./outreach";
import { SettingsView } from "./settings";
import { LeadDrawer } from "./drawer";
import { Palette } from "./palette";

export const NAV: { id: View; label: string; icon: typeof Search; crumb: string }[] = [
  { id: "painel", label: "Visão geral", icon: LayoutDashboard, crumb: "Visão geral" },
  { id: "busca", label: "Radar de busca", icon: Radar, crumb: "Radar de busca" },
  { id: "leads", label: "Leads", icon: Layers3, crumb: "Leads" },
  { id: "pipeline", label: "Pipeline", icon: KanbanSquare, crumb: "Pipeline" },
  { id: "mapa", label: "Mapa", icon: MapIcon, crumb: "Mapa" },
  { id: "abordagem", label: "Abordagem", icon: MessageSquareText, crumb: "Abordagem" },
];

export default function OrbitaApp() {
  return (
    <OrbitaProvider>
      <Shell />
    </OrbitaProvider>
  );
}

function Shell() {
  const { ready, view, setView, leads, settings, updateSettings, setPaletteOpen, apiKey, search, openId } = useOrbita();

  const counts = useMemo(() => {
    let hot = 0, active = 0, reached = 0;
    for (const l of leads) {
      if (l.status !== "novo" && l.status !== "qualificado") reached++;
      if (heatOf(leadScore(l)) === "quente" && l.status === "novo") hot++;
      if (l.status === "contatado" || l.status === "negociando") active++;
    }
    return { total: leads.length, hot, active, reached };
  }, [leads]);

  // Atalhos: Ctrl/Cmd+K abre a paleta; G + letra navega.
  useEffect(() => {
    let g = false, t: ReturnType<typeof setTimeout>;
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable);
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPaletteOpen(true); return; }
      if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === "/") { e.preventDefault(); setPaletteOpen(true); return; }
      if (g) {
        const map: Record<string, View> = { v: "painel", b: "busca", l: "leads", p: "pipeline", m: "mapa", a: "abordagem", c: "ajustes" };
        if (map[e.key]) setView(map[e.key]);
        g = false;
        return;
      }
      if (e.key === "g") { g = true; clearTimeout(t); t = setTimeout(() => (g = false), 900); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setPaletteOpen, setView]);

  // Ferramenta WebMCP (mantida da versão anterior, agora com score e estágio).
  useEffect(() => {
    type ToolDocument = Document & { modelContext?: { registerTool: (tool: object, options: { signal: AbortSignal }) => void | Promise<void> } };
    const context = (document as ToolDocument).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(context.registerTool({
      name: "read_prospect_leads",
      title: "Ler leads encontrados",
      description: "Lista os negócios encontrados, com score, estágio do pipeline e fonte.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true, untrustedContentHint: true },
      execute: () => ({ count: leads.length, leads: leads.map((l) => ({ id: l.id, name: l.name, segment: l.category, city: l.city, phone: l.phone, score: leadScore(l), stage: l.status, mapsUrl: l.mapsUrl })) }),
    }, { signal: lifecycle.signal })).catch(() => {});
    return () => lifecycle.abort();
  }, [leads]);

  const current = NAV.find((n) => n.id === view)?.crumb || "Ajustes";
  const isDark = settings.theme === "dark";
  const coverage = counts.total ? Math.round((counts.reached / counts.total) * 100) : 0;

  return (
    <div className="shell">
      <aside className="sb" aria-label="Menu principal">
        <button className="brand" onClick={() => setView("painel")} aria-label="Órbita — visão geral">
          <Logo className="brand-logo" />
          <div>
            <div className="brand-name">órbita<i>.</i></div>
            <small>PROSPECÇÃO</small>
          </div>
        </button>
        <div className="sb-section">Espaço de trabalho</div>
        <nav className="sb-nav">
          {NAV.map((n) => (
            <button key={n.id} className="sb-item" aria-current={view === n.id ? "page" : undefined} onClick={() => setView(n.id)} title={n.label}>
              <n.icon />
              <span>{n.label}</span>
              {n.id === "leads" && counts.total > 0 && <b className="sb-badge">{counts.total}</b>}
              {n.id === "pipeline" && counts.active > 0 && <b className="sb-badge hot">{counts.active}</b>}
              {n.id === "busca" && search.running && <b className="sb-badge hot">···</b>}
            </button>
          ))}
        </nav>
        <div className="sb-section">Sistema</div>
        <nav className="sb-nav">
          <button className="sb-item" aria-current={view === "ajustes" ? "page" : undefined} onClick={() => setView("ajustes")} title="Ajustes">
            <Settings />
            <span>Ajustes</span>
          </button>
        </nav>
        <div className="sb-foot">
          <div className="sb-card">
            <strong>{counts.hot ? `${counts.hot} ${counts.hot === 1 ? "quente sem contato" : "quentes sem contato"}` : "Carteira em órbita"}</strong>
            <p>{counts.hot ? "Telefone, Instagram e bom ticket — e ninguém falou com eles ainda." : "Cada varredura alimenta seu pipeline com negócios sem site."}</p>
            <div className="sb-meter"><i style={{ width: `${Math.max(3, coverage)}%` }} /></div>
            <div className="sb-meter-row"><span>{counts.reached} abordados</span><span>{coverage}%</span></div>
          </div>
          <div className="sb-status"><span className={`dot ${apiKey || IS_PREVIEW ? "" : "warn"}`} />{IS_PREVIEW ? "Modo prévia · dados simulados" : apiKey ? "Geoapify conectado" : "Chave Geoapify pendente"}</div>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <div className="m-brand"><Logo /><span>órbita<i>.</i></span></div>
          <div className="crumbs"><span className="ws">Workspace</span><span className="sep">/</span><b>{current}</b></div>
          <div className="top-actions">
            <button className="kbar" onClick={() => setPaletteOpen(true)} aria-label="Abrir busca rápida">
              <Search size={15} /><span>Buscar leads, ações…</span><kbd>Ctrl K</kbd>
            </button>
            <button className="btn btn-ghost btn-icon" onClick={() => updateSettings({ theme: isDark ? "light" : "dark" })} aria-label={isDark ? "Usar tema claro" : "Usar tema escuro"} title={isDark ? "Tema claro" : "Tema escuro"}>
              {isDark ? <Sun /> : <Moon />}
            </button>
            <button className="avatar" onClick={() => setView("ajustes")} aria-label="Perfil e ajustes">{(settings.profile.name || "O").trim().charAt(0).toUpperCase()}</button>
          </div>
        </header>

        <main className="page" key={ready ? view : "loading"}>
          {!ready ? null : view === "painel" ? <Dashboard /> : view === "busca" ? <SearchView /> : view === "leads" ? <LeadsView /> : view === "pipeline" ? <PipelineView /> : view === "mapa" ? <MapView /> : view === "abordagem" ? <OutreachView /> : <SettingsView />}
        </main>
      </div>

      <nav className="mnav" aria-label="Navegação">
        {NAV.filter((n) => n.id !== "abordagem").map((n) => (
          <button key={n.id} aria-current={view === n.id ? "page" : undefined} onClick={() => setView(n.id)}>
            <n.icon />
            {n.id === "busca" ? "Radar" : n.id === "painel" ? "Início" : n.label}
          </button>
        ))}
      </nav>

      {openId && <LeadDrawer />}
      <Palette />
      <Toaster theme={isDark ? "dark" : "light"} position="bottom-right" mobileOffset={{ bottom: 84 }} richColors={false} closeButton toastOptions={{ style: { borderRadius: 14, background: "var(--panel)", border: "1px solid var(--line-2)", color: "var(--text)" } }} />
    </div>
  );
}
