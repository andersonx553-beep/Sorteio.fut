"use client";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowUpRight, Database, Download, KeyRound, Keyboard, Moon, Palette, Sparkles, Sun, Trash2, Upload } from "lucide-react";
import type { Lead } from "@/lib/orbita/types";
import { downloadBlob, migrateLead, todayISO } from "@/lib/orbita/utils";
import { useOrbita } from "./store";

export function SettingsView() {
  const { apiKey, setApiKey, settings, updateSettings, leads, setLeads, loadDemo, clearDemo } = useOrbita();
  const [draft, setDraft] = useState("");
  const [armed, setArmed] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const demoCount = leads.filter((l) => l.demo).length;

  const exportBackup = () => {
    const data = { app: "orbita", version: 2, exportedAt: new Date().toISOString(), leads: leads.map((l) => ({ ...l, selected: false })), settings };
    downloadBlob([JSON.stringify(data, null, 2)], "application/json", `orbita-backup-${todayISO()}.json`);
    toast.success("Backup baixado", { description: `${leads.length} leads + modelos e ajustes.` });
  };

  const importBackup = async (file: File) => {
    try {
      const data = JSON.parse(await file.text()) as { leads?: unknown[]; settings?: typeof settings };
      const incoming = (Array.isArray(data.leads) ? data.leads : Array.isArray(data) ? (data as unknown[]) : [])
        .map((x) => migrateLead(x as Record<string, unknown>)).filter(Boolean) as Lead[];
      if (!incoming.length) throw new Error("vazio");
      const known = new Set(leads.map((l) => l.id));
      const fresh = incoming.filter((l) => !known.has(l.id));
      setLeads((old) => { const ids = new Set(old.map((l) => l.id)); return [...fresh.filter((l) => !ids.has(l.id)), ...old]; });
      if (data.settings?.templates?.length) updateSettings({ templates: data.settings.templates, profile: { ...settings.profile, ...data.settings.profile } });
      toast.success("Backup importado", { description: `${fresh.length} leads novos · ${incoming.length - fresh.length} já existiam.` });
    } catch {
      toast.error("Arquivo inválido", { description: "Use um backup JSON exportado pelo Órbita." });
    }
  };

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <span className="eyebrow">Ajustes</span>
          <h1>Sua estação, <em>do seu jeito.</em></h1>
          <p>Chave de dados, aparência e backup. Tudo fica salvo apenas neste navegador.</p>
        </div>
      </div>

      <div className="set-grid">
        <section className="panel fade-up">
          <div className="panel-head"><div className="ico-box"><KeyRound /></div><div><h3>Chave Geoapify</h3><p>Necessária para as varreduras reais</p></div></div>
          <div className="panel-body">
            {apiKey ? (
              <div className="key-box ok">
                <div className="grow"><strong>Conectada</strong><small className="mono">•••• •••• {apiKey.slice(-4)}</small></div>
                <button className="btn btn-sm btn-danger" onClick={() => { setApiKey(""); toast("Chave removida deste navegador"); }}>Esquecer chave</button>
              </div>
            ) : (
              <div style={{ display: "flex", gap: 8 }}>
                <input className="input mono" type="password" placeholder="Cole sua chave" value={draft} onChange={(e) => setDraft(e.target.value.trim())} autoComplete="off" aria-label="Chave Geoapify" />
                <button className="btn btn-primary" disabled={draft.length < 15} onClick={() => { setApiKey(draft); setDraft(""); toast.success("Chave salva"); }}>Salvar</button>
              </div>
            )}
            <p className="hint" style={{ margin: 0 }}>
              Crie grátis em <a href="https://myprojects.geoapify.com/" target="_blank" rel="noopener noreferrer" style={{ color: "var(--accent)" }}>Geoapify MyProjects <ArrowUpRight size={11} style={{ display: "inline" }} /></a>. A chave é enviada apenas ao backend do próprio Órbita para consultar a Geoapify. Evite dispositivos compartilhados.
            </p>
          </div>
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".05s" }}>
          <div className="panel-head"><div className="ico-box"><Palette /></div><div><h3>Aparência</h3><p>Tema da interface</p></div></div>
          <div className="panel-body">
            <div className="seg-tabs" role="group" aria-label="Tema">
              <button aria-pressed={settings.theme === "dark"} onClick={() => updateSettings({ theme: "dark" })}><Moon /> Escuro</button>
              <button aria-pressed={settings.theme === "light"} onClick={() => updateSettings({ theme: "light" })}><Sun /> Claro</button>
            </div>
            <p className="hint" style={{ margin: 0 }}>O mapa acompanha o tema escolhido.</p>
          </div>
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".1s" }}>
          <div className="panel-head"><div className="ico-box"><Database /></div><div><h3>Dados e backup</h3><p>{leads.length} leads salvos neste navegador</p></div></div>
          <div className="panel-body">
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button className="btn" onClick={exportBackup} disabled={!leads.length}><Download /> Exportar backup</button>
              <button className="btn" onClick={() => fileRef.current?.click()}><Upload /> Importar backup</button>
              <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) void importBackup(f); e.target.value = ""; }} />
            </div>
            <p className="hint" style={{ margin: 0 }}>Use o backup para levar sua carteira para outro computador ou navegador. A importação mescla sem duplicar.</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {demoCount ? <button className="btn btn-sm" onClick={clearDemo}><Trash2 /> Remover {demoCount} leads de exemplo</button> : <button className="btn btn-sm" onClick={loadDemo}><Sparkles /> Carregar leads de exemplo</button>}
            </div>
          </div>
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".15s" }}>
          <div className="panel-head"><div className="ico-box"><Keyboard /></div><div><h3>Atalhos</h3><p>Para voar pelo painel</p></div></div>
          <div className="panel-body" style={{ gap: 10 }}>
            {[["Ctrl K  ou  /", "Busca rápida e comandos"], ["G  depois  V", "Visão geral"], ["G  depois  B", "Radar de busca"], ["G  depois  L", "Leads"], ["G  depois  P", "Pipeline"], ["G  depois  M", "Mapa"], ["Esc", "Fechar a ficha do lead"]].map(([k, d]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}><span className="muted">{d}</span><kbd className="k">{k}</kbd></div>
            ))}
          </div>
        </section>

        <section className="panel danger-zone fade-up" style={{ gridColumn: "1 / -1", animationDelay: ".2s" }}>
          <div className="panel-head"><div className="ico-box" style={{ background: "var(--red-soft)", color: "var(--red)", borderColor: "color-mix(in srgb, var(--red) 30%, transparent)" }}><Trash2 /></div><div><h3>Zona de perigo</h3><p>Apaga todos os leads deste navegador. Exporte um backup antes.</p></div><div className="spacer" />
            {armed ? (
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn btn-ghost" onClick={() => setArmed(false)}>Cancelar</button>
                <button className="btn btn-danger" onClick={() => { setLeads([]); setArmed(false); toast("Carteira apagada"); }}>Apagar {leads.length} leads</button>
              </div>
            ) : (
              <button className="btn btn-danger" disabled={!leads.length} onClick={() => setArmed(true)}>Apagar tudo</button>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
