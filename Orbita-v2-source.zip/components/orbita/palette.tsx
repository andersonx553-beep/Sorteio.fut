"use client";
import { useEffect, useMemo, useState } from "react";
import { Command } from "cmdk";
import { ArrowDownToLine, CornerDownLeft, KanbanSquare, LayoutDashboard, Layers3, Map as MapIcon, MessageSquareText, Moon, Radar, Search, Settings, Sparkles, Sun } from "lucide-react";
import { toast } from "sonner";
import type { View } from "@/lib/orbita/types";
import { STAGE_LABEL } from "@/lib/orbita/types";
import { leadScore } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, exportCsv } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { SegmentIcon } from "./icons";

export function Palette() {
  const { paletteOpen, setPaletteOpen, leads, setView, openLead, settings, updateSettings, loadDemo } = useOrbita();
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!paletteOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setPaletteOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [paletteOpen, setPaletteOpen]);

  const top = useMemo(() => [...leads].map((l) => ({ l, s: leadScore(l) })).sort((a, b) => b.s - a.s), [leads]);

  if (!paletteOpen) return null;
  const close = () => { setPaletteOpen(false); setQ(""); };
  const go = (v: View) => { setView(v); close(); };
  const shown = q ? top.slice(0, 400) : top.slice(0, 6);

  return (
    <>
      <div className="cmdk-overlay" onClick={close} />
      <div className="cmdk-box" role="dialog" aria-modal="true" aria-label="Busca rápida">
        <Command label="Busca rápida" loop>
          <div className="cmdk-input-wrap">
            <Search />
            <Command.Input autoFocus value={q} onValueChange={setQ} placeholder="Buscar um negócio ou digitar um comando…" />
          </div>
          <Command.List>
            <Command.Empty>Nada encontrado para “{q}”.</Command.Empty>
            <Command.Group heading="Ir para">
              <Command.Item value="ir visao geral painel dashboard" onSelect={() => go("painel")}><LayoutDashboard />Visão geral</Command.Item>
              <Command.Item value="ir radar busca nova varredura" onSelect={() => go("busca")}><Radar />Nova varredura</Command.Item>
              <Command.Item value="ir leads carteira tabela" onSelect={() => go("leads")}><Layers3 />Leads<span className="r">{leads.length}</span></Command.Item>
              <Command.Item value="ir pipeline kanban funil" onSelect={() => go("pipeline")}><KanbanSquare />Pipeline</Command.Item>
              <Command.Item value="ir mapa territorio" onSelect={() => go("mapa")}><MapIcon />Mapa</Command.Item>
              <Command.Item value="ir abordagem mensagens modelos whatsapp templates" onSelect={() => go("abordagem")}><MessageSquareText />Modelos de mensagem</Command.Item>
              <Command.Item value="ir ajustes configuracoes chave backup" onSelect={() => go("ajustes")}><Settings />Ajustes</Command.Item>
            </Command.Group>
            <Command.Group heading="Ações">
              <Command.Item value="acao alternar tema claro escuro" onSelect={() => { updateSettings({ theme: settings.theme === "dark" ? "light" : "dark" }); close(); }}>{settings.theme === "dark" ? <Sun /> : <Moon />}Alternar para tema {settings.theme === "dark" ? "claro" : "escuro"}</Command.Item>
              {leads.length > 0 && <Command.Item value="acao exportar csv planilha" onSelect={() => { exportCsv(leads, leadScore); toast.success("CSV baixado"); close(); }}><ArrowDownToLine />Exportar todos os leads (CSV)</Command.Item>}
              {!leads.some((l) => l.demo) && <Command.Item value="acao carregar exemplo demo" onSelect={() => { loadDemo(); close(); }}><Sparkles />Carregar leads de exemplo</Command.Item>}
            </Command.Group>
            {shown.length > 0 && (
              <Command.Group heading={q ? "Leads" : "Leads com maior score"}>
                {shown.map(({ l, s }) => (
                  <Command.Item key={l.id} value={`lead ${l.name} ${l.suburb} ${l.city} ${l.category} ${l.id}`} onSelect={() => { openLead(l.id); close(); }}>
                    <SegmentIcon id={l.segment} />
                    <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l.name}</span>
                    <span className="r">{SEGMENT_BY_ID[l.segment]?.short} · {l.suburb || cityOnly(l.city)} · {STAGE_LABEL[l.status]} · <b className="mono">{s}</b></span>
                  </Command.Item>
                ))}
              </Command.Group>
            )}
          </Command.List>
          <div className="cmdk-foot"><span><kbd className="k">↑↓</kbd> navegar</span><span><kbd className="k"><CornerDownLeft size={10} /></kbd> abrir</span><span><kbd className="k">Esc</kbd> fechar</span></div>
        </Command>
      </div>
    </>
  );
}
