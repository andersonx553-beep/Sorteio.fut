import type { SVGProps } from "react";
import {
  Beer, BedDouble, Calculator, Camera, Car, Coffee, Croissant, Dumbbell, Flower2, Gem, Glasses, House,
  IceCreamCone, Languages, Music, PawPrint, PenTool, Pill, Plane, Sandwich, Scale, Scissors, Shirt, ShoppingBag, Sofa,
  Sparkles, Stethoscope, Store, Syringe, UtensilsCrossed, WashingMachine, Wrench, DraftingCompass, CarFront,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true" {...props}>
      <defs>
        <radialGradient id="lg-core" cx="35%" cy="30%" r="75%">
          <stop offset="0" stopColor="#ffe3a3" />
          <stop offset=".55" stopColor="#f2b544" />
          <stop offset="1" stopColor="#b86e0e" />
        </radialGradient>
      </defs>
      <ellipse cx="20" cy="20" rx="18" ry="8" transform="rotate(-28 20 20)" stroke="#f2b544" strokeOpacity=".35" strokeWidth="1.6" />
      <circle cx="20" cy="20" r="8.5" fill="url(#lg-core)" />
      <path d="M4.3 27.8C9 31.4 22 27 32.5 16.6" stroke="#f2b544" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="33.6" cy="14.6" r="2.6" fill="#5eead4" />
    </svg>
  );
}

export function InstagramIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function WhatsAppIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.98L2 22l5.16-1.5A9.9 9.9 0 1 0 12.04 2Zm0 18.1a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.06.89.9-2.98-.2-.31a8.2 8.2 0 1 1 6.85 3.73Zm4.5-6.14c-.25-.12-1.46-.72-1.69-.8-.23-.08-.39-.12-.56.13-.16.25-.64.8-.79.97-.14.16-.29.18-.54.06-.25-.12-1.04-.38-1.98-1.22-.73-.65-1.23-1.46-1.37-1.7-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.16-.25.25-.41.08-.17.04-.31-.02-.44-.06-.12-.56-1.35-.77-1.84-.2-.48-.41-.42-.56-.43h-.48a.92.92 0 0 0-.66.31c-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.57.12.16 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.46-.6 1.67-1.18.2-.58.2-1.07.14-1.18-.06-.1-.22-.16-.47-.28Z" />
    </svg>
  );
}

export function FacebookIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      <path d="M15 3h-2a4 4 0 0 0-4 4v3H7v4h2v7h4v-7h3l1-4h-4V7a1 1 0 0 1 1-1h2z" />
    </svg>
  );
}

const SEG_ICONS: Record<string, LucideIcon> = {
  restaurant: UtensilsCrossed, cafe: Coffee, fastfood: Sandwich, bar: Beer, icecream: IceCreamCone, bakery: Croissant,
  barber: Scissors, beauty: Sparkles, tattoo: PenTool, gym: Dumbbell,
  dentist: Syringe, clinic: Stethoscope, pharmacy: Pill, optician: Glasses,
  lawyer: Scale, accountant: Calculator, estate: House, architect: DraftingCompass, photographer: Camera, laundry: WashingMachine,
  retail: ShoppingBag, clothing: Shirt, furniture: Sofa, jewelry: Gem, florist: Flower2,
  auto: Wrench, vehicle: Car, driving: CarFront, language: Languages, music: Music,
  hotel: BedDouble, travel: Plane, pet: PawPrint, veterinary: Stethoscope,
};

export function SegmentIcon({ id, ...props }: { id: string } & SVGProps<SVGSVGElement>) {
  const I = SEG_ICONS[id] || Store;
  return <I {...(props as object)} />;
}

