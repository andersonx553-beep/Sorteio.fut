"use client";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { CheckCheck, Copy, FileText, Plus, RotateCcw, Star, Trash2, UserRound } from "lucide-react";
import type { Lead } from "@/lib/orbita/types";
import { DEFAULT_TEMPLATES } from "@/lib/orbita/defaults";
import { leadScore } from "@/lib/orbita/score";
import { cityOnly, fillTemplate } from "@/lib/orbita/utils";
import { useOrbita } from "./store";

const VARS: [string, string][] = [
  ["nome", "Nome do negócio"], ["segmento", "Segmento"], ["bairro", "Bairro"], ["cidade", "Cidade"], ["instagram", "@ do Instagram"],
  ["meu_nome", "Seu nome"], ["minha_empresa", "Sua empresa"], ["portfolio", "Link do portfólio"],
];

const SAMPLE: Lead = {
  id: "sample", name: "Café Mandacaru", segment: "cafe", category: "Cafeteria", city: "Fortaleza, Brasil", address: "Rua Silva Paulet, 1200", suburb: "Aldeota", postcode: "",
  phone: "(85) 99999-0000", whatsapp: "", email: "", instagramUrl: "https://www.instagram.com/cafemandacaru/", facebookUrl: "", openingHours: "", socialOnly: true, distance: 1200,
  mapsUrl: "", lat: 0, lon: 0, status: "novo", selected: false, starred: false, notes: "", followUp: "", value: 0, foundAt: "", updatedAt: "", history: [],
};

export function OutreachView() {
  const { settings, updateSettings, leads } = useOrbita();
  const [currentId, setCurrentId] = useState(settings.templates[0]?.id);
  const current = settings.templates.find((t) => t.id === currentId) || settings.templates[0];
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const sample = useMemo(() => [...leads].sort((a, b) => leadScore(b) - leadScore(a))[0] || SAMPLE, [leads]);

  const patchTemplate = (patch: Partial<{ name: string; body: string }>) =>
    updateSettings({ templates: settings.templates.map((t) => (t.id === current.id ? { ...t, ...patch } : t)) });

  const insertVar = (v: string) => {
    const el = areaRef.current;
    const token = `{${v}}`;
    if (!el) return patchTemplate({ body: current.body + token });
    const start = el.selectionStart, end = el.selectionEnd;
    const body = current.body.slice(0, start) + token + current.body.slice(end);
    patchTemplate({ body });
    requestAnimationFrame(() => { el.focus(); el.selectionStart = el.selectionEnd = start + token.length; });
  };

  const addTemplate = () => {
    const id = "tpl-" + Date.now().toString(36);
    updateSettings({ templates: [...settings.templates, { id, name: "Novo modelo", body: "Oi! Aqui é {meu_nome}, da {minha_empresa}. " }] });
    setCurrentId(id);
  };
  const removeTemplate = () => {
    if (settings.templates.length <= 1) return;
    const rest = settings.templates.filter((t) => t.id !== current.id);
    updateSettings({ templates: rest, defaultTemplate: settings.defaultTemplate === current.id ? rest[0].id : settings.defaultTemplate });
    setCurrentId(rest[0].id);
  };

  // Pré-visualização com destaque do que foi preenchido automaticamente.
  const preview = useMemo(() => {
    if (!current) return [];
    const parts: { text: string; filled: boolean }[] = [];
    const re = /\{(\w+)\}/g;
    let last = 0, m: RegExpExecArray | null;
    while ((m = re.exec(current.body))) {
      parts.push({ text: current.body.slice(last, m.index), filled: false });
      parts.push({ text: fillTemplate(m[0], sample, settings.profile), filled: true });
      last = m.index + m[0].length;
    }
    parts.push({ text: current.body.slice(last), filled: false });
    return parts;
  }, [current, sample, settings.profile]);

  const profile = settings.profile;
  const setProfile = (patch: Partial<typeof profile>) => updateSettings({ profile: { ...profile, ...patch } });

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <span className="eyebrow">Abordagem</span>
          <h1>Mensagens que <em>soam como você.</em></h1>
          <p>Modelos com variáveis que se preenchem sozinhas para cada negócio. Na ficha do lead, um toque abre o WhatsApp com o texto pronto — o envio é sempre seu.</p>
        </div>
      </div>

      <section className="panel fade-up" style={{ marginBottom: 14 }}>
        <div className="panel-head">
          <div className="ico-box"><UserRound /></div>
          <div><h3>Quem está falando</h3><p>Usado nas variáveis {"{meu_nome}"}, {"{minha_empresa}"} e {"{portfolio}"}</p></div>
        </div>
        <div className="panel-body" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14 }}>
          <label><span className="label">Seu nome</span><input className="input" value={profile.name} placeholder="Ex.: Ana Souza" onChange={(e) => setProfile({ name: e.target.value })} /></label>
          <label><span className="label">Sua empresa ou estúdio</span><input className="input" value={profile.company} placeholder="Ex.: Studio Órbita Web" onChange={(e) => setProfile({ company: e.target.value })} /></label>
          <label><span className="label">Link do portfólio</span><input className="input" value={profile.portfolio} placeholder="https://…" onChange={(e) => setProfile({ portfolio: e.target.value })} /></label>
        </div>
      </section>

      <div className="tpl-layout">
        <section className="panel fade-up">
          <div className="panel-head" style={{ padding: "14px 16px" }}>
            <h3>Modelos</h3>
            <div className="spacer" />
            <button className="btn btn-sm btn-ghost btn-icon" onClick={addTemplate} aria-label="Novo modelo"><Plus /></button>
          </div>
          <div className="tpl-list">
            {settings.templates.map((t) => (
              <button key={t.id} className="tpl-item" aria-current={t.id === current?.id} onClick={() => setCurrentId(t.id)}>
                <FileText />{t.name}{settings.defaultTemplate === t.id && <span className="def">PADRÃO</span>}
              </button>
            ))}
          </div>
          <div style={{ padding: "8px 12px 14px" }}>
            <button className="btn btn-sm btn-ghost" style={{ width: "100%" }} onClick={() => { updateSettings({ templates: DEFAULT_TEMPLATES, defaultTemplate: DEFAULT_TEMPLATES[0].id }); setCurrentId(DEFAULT_TEMPLATES[0].id); toast("Modelos originais restaurados"); }}><RotateCcw /> Restaurar originais</button>
          </div>
        </section>

        {current && (
          <section className="panel fade-up" style={{ animationDelay: ".05s" }}>
            <div className="panel-head" style={{ flexWrap: "wrap" }}>
              <input className="input" style={{ maxWidth: 280, fontWeight: 600 }} value={current.name} onChange={(e) => patchTemplate({ name: e.target.value })} aria-label="Nome do modelo" />
              <div className="spacer" />
              <button className="btn btn-sm" disabled={settings.defaultTemplate === current.id} onClick={() => updateSettings({ defaultTemplate: current.id })}><Star /> Usar como padrão</button>
              <button className="btn btn-sm btn-danger btn-icon" disabled={settings.templates.length <= 1} onClick={removeTemplate} aria-label="Excluir modelo"><Trash2 /></button>
            </div>
            <div className="panel-body" style={{ display: "grid", gap: 14 }}>
              <div>
                <div className="label">Variáveis <span>clique para inserir no cursor</span></div>
                <div className="vars">{VARS.map(([v, label]) => <button key={v} className="var" title={label} onClick={() => insertVar(v)}>{`{${v}}`}</button>)}</div>
              </div>
              <textarea ref={areaRef} className="textarea" rows={13} value={current.body} onChange={(e) => patchTemplate({ body: e.target.value })} aria-label="Texto do modelo" />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                <span className="hint" style={{ margin: 0 }}>{current.body.length} caracteres · mensagens curtas e pessoais têm mais resposta.</span>
                <button className="btn btn-sm" onClick={() => navigator.clipboard?.writeText(fillTemplate(current.body, sample, profile)).then(() => toast.success("Prévia copiada"))}><Copy /> Copiar prévia</button>
              </div>
            </div>
          </section>
        )}

        <div className="phone-col fade-up" style={{ animationDelay: ".1s" }}>
          <div className="phone">
            <div className="phone-top">
              <span className="av">{sample.name.charAt(0)}</span>
              <div><strong>{sample.name}</strong><small>{cityOnly(sample.city)} · prévia com {sample === SAMPLE ? "exemplo" : "seu lead de maior score"}</small></div>
            </div>
            <div className="chat">
              <div className="bubble">
                {preview.map((p, i) => (p.filled ? <mark key={i}>{p.text}</mark> : <span key={i}>{p.text}</span>))}
                <time>{new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}<CheckCheck /></time>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
