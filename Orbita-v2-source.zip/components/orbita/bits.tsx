"use client";
import { Check, Flame, Mail, Minus, Phone, Snowflake, Thermometer } from "lucide-react";
import type { Lead, Stage } from "@/lib/orbita/types";
import { STAGE_LABEL } from "@/lib/orbita/types";
import { heatOf, HEAT_LABEL, type Heat } from "@/lib/orbita/score";
import { isLikelyMobile } from "@/lib/orbita/utils";
import { InstagramIcon, WhatsAppIcon } from "./icons";

export const STAGE_COLOR: Record<Stage, string> = {
  novo: "var(--cyan)", qualificado: "var(--blue)", contatado: "var(--violet)", negociando: "var(--accent)", fechado: "var(--green)", perdido: "var(--slate)",
};

export function StagePill({ stage }: { stage: Stage }) {
  return <span className={`pill st-${stage}`}>{STAGE_LABEL[stage]}</span>;
}

export function HeatTag({ heat }: { heat: Heat }) {
  const I = heat === "quente" ? Flame : heat === "morno" ? Thermometer : Snowflake;
  return <span className={`heat ${heat}`}><I />{HEAT_LABEL[heat]}</span>;
}

export function ScoreBadge({ score }: { score: number }) {
  const h = heatOf(score);
  return (
    <span className={`score h-${h}`} title={`Score ${score} · ${HEAT_LABEL[h]}`}>
      {score}
      <span className="score-bar"><i style={{ width: `${score}%` }} /></span>
    </span>
  );
}

export function ScoreRing({ score, size = 116 }: { score: number; size?: number }) {
  const h = heatOf(score);
  const r = 50, c = 2 * Math.PI * r;
  const color = h === "quente" ? "var(--orange)" : h === "morno" ? "var(--accent)" : "var(--blue)";
  return (
    <div className="score-ring" style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120">
        <circle cx="60" cy="60" r={r} fill="none" stroke="var(--line-2)" strokeWidth="9" />
        <circle cx="60" cy="60" r={r} fill="none" stroke={color} strokeWidth="9" strokeLinecap="round" strokeDasharray={`${(score / 100) * c} ${c}`} style={{ transition: "stroke-dasharray .8s cubic-bezier(.2,.8,.2,1)", filter: `drop-shadow(0 0 6px ${color})` }} />
      </svg>
      <div className="ring-val">
        <b>{score}</b>
        <span style={{ color }}>{HEAT_LABEL[h]}</span>
      </div>
    </div>
  );
}

export function ContactDots({ lead }: { lead: Lead }) {
  const wa = isLikelyMobile(lead);
  return (
    <span className="cdots">
      <span className={`cdot ${lead.phone ? "on" : ""}`} title={lead.phone || "Sem telefone"}><Phone /></span>
      <span className={`cdot wa ${wa ? "on" : ""}`} title={wa ? "Provável WhatsApp" : "Sem WhatsApp identificado"}><WhatsAppIcon /></span>
      <span className={`cdot ig ${lead.instagramUrl ? "on" : ""}`} title={lead.instagramUrl ? "Instagram informado" : "Instagram não informado"}><InstagramIcon /></span>
      <span className={`cdot ${lead.email ? "on" : ""}`} title={lead.email || "Sem e-mail"}><Mail /></span>
    </span>
  );
}

export function CheckBox({ checked, onChange, label }: { checked: boolean | "mixed"; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      className="check"
      onClick={(e) => { e.stopPropagation(); onChange(checked !== true); }}
    >
      {checked === "mixed" ? <Minus strokeWidth={3} /> : <Check strokeWidth={3} />}
    </button>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className="switch" onClick={() => onChange(!checked)} />;
}

/** Arte orbital decorativa (hero e estados vazios). */
export function OrbitArt({ className, planets = true }: { className?: string; planets?: boolean }) {
  return (
    <svg className={className} viewBox="0 0 400 400" fill="none" aria-hidden="true">
      <defs>
        <radialGradient id="oa-core" cx="38%" cy="32%" r="70%">
          <stop offset="0" stopColor="#ffe3a3" />
          <stop offset=".5" stopColor="#f2b544" />
          <stop offset="1" stopColor="#8a4f06" />
        </radialGradient>
        <radialGradient id="oa-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor="#f2b544" stopOpacity=".35" />
          <stop offset="1" stopColor="#f2b544" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="200" cy="200" r="120" fill="url(#oa-glow)" />
      <circle cx="200" cy="200" r="178" stroke="currentColor" strokeOpacity=".08" />
      <circle cx="200" cy="200" r="140" stroke="currentColor" strokeOpacity=".1" strokeDasharray="2 6" />
      <circle cx="200" cy="200" r="100" stroke="currentColor" strokeOpacity=".12" />
      <circle cx="200" cy="200" r="62" stroke="#f2b544" strokeOpacity=".25" />
      <circle cx="200" cy="200" r="34" fill="url(#oa-core)" />
      {planets && (
        <>
          <g className="spin-60"><circle cx="200" cy="22" r="6" fill="#5eead4" /><circle cx="200" cy="22" r="12" stroke="#5eead4" strokeOpacity=".3" /></g>
          <g className="spin-40r"><circle cx="340" cy="200" r="5" fill="#f2b544" /></g>
          <g className="spin-25"><circle cx="200" cy="300" r="4" fill="#7aa2ff" /><circle cx="200" cy="300" r="9" stroke="#7aa2ff" strokeOpacity=".3" /></g>
          <g className="spin-40r"><circle cx="62" cy="200" r="3.5" fill="#b69cff" /></g>
        </>
      )}
    </svg>
  );
}

export function Sparkline({ values, color = "var(--accent)" }: { values: number[]; color?: string }) {
  const max = Math.max(1, ...values);
  const w = 200, h = 56;
  const pts = values.map((v, i) => [(i / Math.max(1, values.length - 1)) * w, h - 6 - (v / max) * (h - 14)]);
  const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const id = "sp" + color.replace(/[^a-z]/gi, "");
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity=".28" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${d} L${w} ${h} L0 ${h} Z`} fill={`url(#${id})`} />
      <path d={d} stroke={color} strokeWidth="1.8" fill="none" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export function heatClass(score: number) {
  return heatOf(score);
}
