"use client";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, ChevronDown, ChevronUp, Clock, Copy, ExternalLink, Globe, Mail, MapPin, Navigation, Phone, Search, Star, Trash2, X } from "lucide-react";
import type { Lead } from "@/lib/orbita/types";
import { STAGES } from "@/lib/orbita/types";
import { leadScore, scoreFactors } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, fillTemplate, formatDistance, googleMapsLink, googleSearchLink, instagramHandle, instagramLink, isLikelyMobile, relativeTime, whatsappLink, whatsappNumber } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { FacebookIcon, InstagramIcon, SegmentIcon, WhatsAppIcon } from "./icons";
import { ScoreRing, STAGE_COLOR } from "./bits";

function copy(text: string, what: string) {
  navigator.clipboard?.writeText(text).then(() => toast.success(`${what} copiado`), () => toast.error("Não foi possível copiar"));
}

export function LeadDrawer() {
  const { leads, openId, openLead } = useOrbita();
  const lead = leads.find((l) => l.id === openId);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") openLead(null); };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [openLead]);

  if (!lead) return null;
  return (
    <>
      <div className="scrim" onClick={() => openLead(null)} />
      <aside className="drawer" role="dialog" aria-modal="true" aria-label={`Ficha de ${lead.name}`}>
        <DrawerContent key={lead.id} lead={lead} />
      </aside>
    </>
  );
}

function DrawerContent({ lead }: { lead: Lead }) {
    const { leads, openLead, updateLead, setStage, removeLeads, settings, setView } = useOrbita();
    const score = leadScore(lead);
    const factors = useMemo(() => scoreFactors(lead), [lead]);
    const [tplId, setTplId] = useState(settings.defaultTemplate);
    const tpl = settings.templates.find((t) => t.id === tplId) || settings.templates[0];
    const [message, setMessage] = useState(() => (tpl ? fillTemplate(tpl.body, lead, settings.profile) : ""));
    const [notes, setNotes] = useState(lead.notes);
    const [showMsg, setShowMsg] = useState(false);
    const ig = instagramLink(lead);
    const wa = whatsappNumber(lead);
    const mobile = isLikelyMobile(lead);
    const seg = SEGMENT_BY_ID[lead.segment];
    const list = leads;
    const idx = list.findIndex((l) => l.id === lead.id);

    const markContact = (channel: string) => {
      updateLead(lead.id, {}, `${channel} aberto${channel === "WhatsApp" ? ` com a mensagem “${tpl?.name}”` : ""}`, "contact");
      if (lead.status === "novo" || lead.status === "qualificado") {
        toast(`Marcar ${lead.name} como contatado?`, { action: { label: "Marcar", onClick: () => setStage([lead.id], "contatado") }, duration: 8000 });
      }
    };
    const guardDemo = (e: React.MouseEvent) => {
      if (lead.demo) { e.preventDefault(); toast("Este é um lead de exemplo", { description: "O contato é fictício. Em leads reais, este botão abre o app direto." }); return true; }
      return false;
    };

    return (
      <>
        <header className="dr-head">
          <span className="eyebrow"><SegmentIcon id={lead.segment} width={13} height={13} /> {seg?.short || lead.category}{lead.demo ? " · exemplo" : ""}</span>
          <h2>{lead.name}</h2>
          <p>{[lead.suburb, cityOnly(lead.city), formatDistance(lead.distance) && `${formatDistance(lead.distance)} do centro`].filter(Boolean).join(" · ")}</p>
          <div className="dr-close">
            <button className="btn btn-sm btn-ghost btn-icon" disabled={idx <= 0} onClick={() => openLead(list[idx - 1].id)} aria-label="Lead anterior"><ChevronUp /></button>
            <button className="btn btn-sm btn-ghost btn-icon" disabled={idx >= list.length - 1} onClick={() => openLead(list[idx + 1].id)} aria-label="Próximo lead"><ChevronDown /></button>
            <button className={`btn btn-sm btn-ghost btn-icon ${lead.starred ? "" : ""}`} style={lead.starred ? { color: "var(--accent)" } : undefined} onClick={() => updateLead(lead.id, { starred: !lead.starred })} aria-label={lead.starred ? "Remover dos favoritos" : "Favoritar"}><Star fill={lead.starred ? "currentColor" : "none"} /></button>
            <button className="btn btn-sm btn-ghost btn-icon" onClick={() => openLead(null)} aria-label="Fechar"><X /></button>
          </div>
        </header>

        <div className="dr-body">
          <section className="dr-section">
            <h4>Estágio</h4>
            <div className="stage-picker" role="group" aria-label="Estágio do pipeline">
              {STAGES.map((s) => (
                <button key={s.id} aria-pressed={lead.status === s.id} style={{ ["--c" as string]: STAGE_COLOR[s.id] }} onClick={() => setStage([lead.id], s.id)} title={s.hint}>{s.label}</button>
              ))}
            </div>
          </section>

          <section className="dr-section">
            <h4>Abordar</h4>
            <div className="actions-grid">
              <button className={`act wa ${wa ? "" : "disabled"}`} onClick={() => setShowMsg((v) => !v)} aria-expanded={showMsg}><WhatsAppIcon />WhatsApp</button>
              <a className={`act ${lead.phone ? "" : "disabled"}`} href={lead.phone ? `tel:+${wa || lead.phone.replace(/\D/g, "")}` : undefined} onClick={(e) => { if (!guardDemo(e)) markContact("Ligação"); }}><Phone />Ligar</a>
              <a className="act ig" href={ig.url} target="_blank" rel="noopener noreferrer" onClick={(e) => { if (!guardDemo(e) && ig.found) markContact("Instagram"); }}><InstagramIcon />{ig.found ? "Instagram" : "Achar Insta"}</a>
              <a className="act" href={googleSearchLink(lead)} target="_blank" rel="noopener noreferrer" title="Confira se o negócio realmente não tem site"><Search />Checar site</a>
            </div>
            {!wa && <p className="hint">Sem telefone na ficha do OSM. Tente achar o contato pelo Instagram ou pelo Google.</p>}
            {wa && !mobile && <p className="hint">Esse número parece fixo — o WhatsApp pode não funcionar. Ligar costuma ser melhor.</p>}
            {showMsg && wa && (
              <div className="panel fade-up" style={{ marginTop: 12, boxShadow: "none" }}>
                <div className="panel-head" style={{ padding: "12px 14px" }}>
                  <WhatsAppIcon width={16} height={16} style={{ color: "#25d366" }} />
                  <h3 style={{ fontSize: 13.5 }}>Mensagem</h3>
                  <div className="spacer" />
                  <select className="select" style={{ height: 32, width: "auto", fontSize: 12.5 }} value={tplId} onChange={(e) => { setTplId(e.target.value); const t = settings.templates.find((x) => x.id === e.target.value); if (t) setMessage(fillTemplate(t.body, lead, settings.profile)); }} aria-label="Modelo de mensagem">
                    {settings.templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div style={{ padding: 14, display: "grid", gap: 10 }}>
                  <textarea className="textarea" rows={7} value={message} onChange={(e) => setMessage(e.target.value)} aria-label="Texto da mensagem" />
                  {(!settings.profile.name || !settings.profile.company) && (
                    <p className="hint" style={{ margin: 0 }}>Dica: preencha seu nome e empresa em <button style={{ color: "var(--accent)", textDecoration: "underline" }} onClick={() => { openLead(null); setView("ajustes"); }}>Ajustes</button> para personalizar os modelos.</p>
                  )}
                  <div style={{ display: "flex", gap: 8 }}>
                    <a className="btn btn-wa" style={{ flex: 1 }} href={whatsappLink(lead, message)} target="_blank" rel="noopener noreferrer" onClick={(e) => { if (!guardDemo(e)) markContact("WhatsApp"); }}><WhatsAppIcon /> Abrir no WhatsApp</a>
                    <button className="btn" onClick={() => copy(message, "Texto")}><Copy /> Copiar</button>
                  </div>
                </div>
              </div>
            )}
          </section>

          <section className="dr-section">
            <h4>Score do lead</h4>
            <div className="score-card">
              <ScoreRing score={score} />
              <div className="factors">
                {factors.map((f) => (
                  <div key={f.label} className={f.hit ? "" : "miss"}>{f.hit ? <Check /> : <X />}{f.label}<b>+{f.points}</b></div>
                ))}
              </div>
            </div>
          </section>

          <section className="dr-section">
            <h4>Contato e localização</h4>
            <div className="info-list">
              <Info icon={<Phone />} k="Telefone" v={lead.phone} copyLabel="Telefone" href={lead.phone ? `tel:+${wa}` : undefined} />
              <Info icon={<WhatsAppIcon />} k="WhatsApp" v={wa ? `+${wa}${mobile ? "" : " (fixo?)"}` : ""} copyLabel="Número" copyValue={wa} />
              <Info icon={<InstagramIcon />} k="Instagram" v={ig.found ? instagramHandle(ig.url) : ""} href={ig.found ? ig.url : undefined} copyLabel="Instagram" copyValue={ig.found ? ig.url : ""} />
              {lead.facebookUrl && <Info icon={<FacebookIcon />} k="Facebook" v={lead.facebookUrl.replace(/^https?:\/\/(www\.)?/, "")} href={lead.facebookUrl} copyLabel="Link" copyValue={lead.facebookUrl} />}
              <Info icon={<Mail />} k="E-mail" v={lead.email} href={lead.email ? `mailto:${lead.email}` : undefined} copyLabel="E-mail" />
              <Info icon={<MapPin />} k="Endereço" v={[lead.address, lead.suburb, lead.postcode].filter(Boolean).join(" · ")} copyLabel="Endereço" copyValue={[lead.address, lead.suburb, cityOnly(lead.city), lead.postcode].filter(Boolean).join(", ")} />
              <Info icon={<Clock />} k="Horário" v={lead.openingHours} />
              <div className="info-row">
                <Navigation />
                <span className="k">Mapas</span>
                <span className="v" style={{ display: "flex", gap: 12 }}>
                  <a href={googleMapsLink(lead)} target="_blank" rel="noopener noreferrer">Google Maps <ExternalLink size={11} style={{ display: "inline" }} /></a>
                  <a href={lead.mapsUrl} target="_blank" rel="noopener noreferrer">Ficha OSM <ExternalLink size={11} style={{ display: "inline" }} /></a>
                </span>
              </div>
            </div>
          </section>

          <section className="dr-section">
            <h4>Negócio</h4>
            <div className="two">
              <label>
                <span className="label">Valor estimado</span>
                <div className="input-wrap"><span style={{ position: "absolute", left: 12, top: "50%", translate: "0 -50%", color: "var(--text-3)", fontSize: 13 }}>R$</span>
                  <input className="input num" style={{ paddingLeft: 36 }} type="number" min={0} step={100} value={lead.value || ""} placeholder="0" onChange={(e) => updateLead(lead.id, { value: Math.max(0, Number(e.target.value) || 0) })} />
                </div>
              </label>
              <label>
                <span className="label">Próximo retorno</span>
                <input className="input" type="date" value={lead.followUp} onChange={(e) => updateLead(lead.id, { followUp: e.target.value }, e.target.value ? `Retorno agendado para ${e.target.value.split("-").reverse().join("/")}` : "Retorno removido", "note")} />
              </label>
            </div>
          </section>

          <section className="dr-section">
            <h4>Notas</h4>
            <textarea className="textarea" rows={4} placeholder="O que foi conversado, objeções, o que o cliente quer no site…" value={notes} onChange={(e) => setNotes(e.target.value)} onBlur={() => { if (notes !== lead.notes) updateLead(lead.id, { notes }, "Nota atualizada", "note"); }} />
          </section>

          <section className="dr-section">
            <h4>Histórico</h4>
            <div className="timeline">
              {[...lead.history].reverse().map((h, i) => (
                <div className={`tl-item ${h.kind}`} key={i}><i /><div>{h.text}<time>{relativeTime(h.at)} · {new Date(h.at).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</time></div></div>
              ))}
            </div>
          </section>

          <section className="dr-section" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, paddingTop: 8, borderTop: "1px solid var(--line)" }}>
            <span className="hint" style={{ margin: 0 }}><Globe size={12} style={{ display: "inline", verticalAlign: -1 }} /> Dados © OpenStreetMap contributors (ODbL)</span>
            <button className="btn btn-sm btn-danger" onClick={() => removeLeads([lead.id])}><Trash2 /> Remover lead</button>
          </section>
        </div>
      </>
    );
}

function Info({ icon, k, v, href, copyLabel, copyValue }: { icon: React.ReactNode; k: string; v: string; href?: string; copyLabel?: string; copyValue?: string }) {
  return (
    <div className="info-row">
      {icon}
      <span className="k">{k}</span>
      <span className={`v ${v ? "" : "empty"}`}>{v ? (href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer">{v}</a> : v) : "Não informado"}</span>
      {v && copyLabel && <button className="copy-btn" onClick={() => copy(copyValue || v, copyLabel)} aria-label={`Copiar ${copyLabel.toLowerCase()}`}><Copy /></button>}
    </div>
  );
}
