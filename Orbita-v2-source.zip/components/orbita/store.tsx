"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import type { ApiLead, Lead, Settings, Stage, View } from "@/lib/orbita/types";
import { STAGE_LABEL } from "@/lib/orbita/types";
import { DEFAULT_SETTINGS, DEFAULT_TEMPLATES, STORAGE_KEY, STORAGE_LEADS, STORAGE_LEADS_V1, STORAGE_SETTINGS } from "@/lib/orbita/defaults";
import { migrateLead } from "@/lib/orbita/utils";
import { buildDemoLeads } from "@/lib/orbita/demo";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { searchGeoapify, SearchError } from "@/lib/orbita/search-geoapify";

export type ScanLog = { id: number; at: number; kind: "info" | "ok" | "warn" | "error"; text: string };
export type RadarBlip = { id: string; bearing: number; dist: number; heat: number };
export type SearchState = {
  running: boolean;
  done: number;
  total: number;
  current: string;
  added: number;
  scanned: number;
  withSite: number;
  chains: number;
  log: ScanLog[];
  blips: RadarBlip[];
  radius: number;
  finishedAt: number | null;
};

/** Prévia estática (sem backend): marca os resultados simulados como exemplo. */
export const IS_PREVIEW = typeof window !== "undefined" && (window as { __ORBITA_PREVIEW__?: boolean }).__ORBITA_PREVIEW__ === true;

const IDLE: SearchState = { running: false, done: 0, total: 0, current: "", added: 0, scanned: 0, withSite: 0, chains: 0, log: [], blips: [], radius: 6000, finishedAt: null };

type SearchInput = { places: string[]; segments: string[]; radius: number; depth: number; excludeChains: boolean };

type Store = {
  ready: boolean;
  leads: Lead[];
  setLeads: React.Dispatch<React.SetStateAction<Lead[]>>;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  apiKey: string;
  setApiKey: (k: string) => void;
  view: View;
  setView: (v: View) => void;
  openId: string | null;
  openLead: (id: string | null) => void;
  paletteOpen: boolean;
  setPaletteOpen: (v: boolean) => void;
  updateLead: (id: string, patch: Partial<Lead>, historyText?: string, kind?: Lead["history"][number]["kind"]) => void;
  setStage: (ids: string[], stage: Stage) => void;
  removeLeads: (ids: string[]) => void;
  loadDemo: () => void;
  clearDemo: () => void;
  search: SearchState;
  startSearch: (input: SearchInput) => Promise<void>;
  cancelSearch: () => void;
};

const Ctx = createContext<Store | null>(null);
export const useOrbita = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useOrbita fora do provider");
  return c;
};

function readJSON<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

function bearingDist(c: { lat: number; lon: number }, lat: number, lon: number) {
  const dy = (lat - c.lat) * 111320;
  const dx = (lon - c.lon) * 111320 * Math.cos((c.lat * Math.PI) / 180);
  return { bearing: Math.atan2(dy, dx), dist: Math.sqrt(dx * dx + dy * dy) };
}

export function OrbitaProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [apiKey, setApiKeyState] = useState("");
  const [view, setViewState] = useState<View>("painel");
  const [openId, setOpenId] = useState<string | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [search, setSearch] = useState<SearchState>(IDLE);
  const cancelRef = useRef(false);
  const logId = useRef(0);
  const leadsRef = useRef<Lead[]>([]);
  useEffect(() => { leadsRef.current = leads; }, [leads]);

  // Carregamento inicial + migração do formato v1.
  useEffect(() => {
    let stored = readJSON<unknown[]>(STORAGE_LEADS, []);
    if (!Array.isArray(stored) || !stored.length) stored = readJSON<unknown[]>(STORAGE_LEADS_V1, []);
    const migrated = (Array.isArray(stored) ? stored : []).map((x) => migrateLead(x as Record<string, unknown>)).filter(Boolean) as Lead[];
    const s = readJSON<Partial<Settings>>(STORAGE_SETTINGS, {});
    const merged: Settings = {
      ...DEFAULT_SETTINGS,
      ...s,
      profile: { ...DEFAULT_SETTINGS.profile, ...(s.profile || {}) },
      templates: Array.isArray(s.templates) && s.templates.length ? s.templates : DEFAULT_TEMPLATES,
    };
    let key = "";
    try {
      key = localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY) || "";
      sessionStorage.removeItem(STORAGE_KEY);
    } catch {}
    /* eslint-disable react-hooks/set-state-in-effect -- hidratação única a partir do armazenamento local */
    setLeads(migrated);
    setSettings(merged);
    setApiKeyState(key);
    try {
      const v = new URLSearchParams(location.search).get("v") as View | null;
      if (v) setViewState(v);
      else if (!migrated.length) setViewState("busca");
    } catch {}
    setReady(true);
    /* eslint-enable react-hooks/set-state-in-effect */
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE_LEADS, JSON.stringify(leads.map((l) => ({ ...l, selected: false }))));
    } catch {
      toast.error("Não foi possível salvar no navegador. O armazenamento pode estar cheio.");
    }
  }, [leads, ready]);

  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings)); } catch {}
    document.documentElement.dataset.theme = settings.theme;
  }, [settings, ready]);

  const setApiKey = useCallback((k: string) => {
    setApiKeyState(k);
    try {
      if (k) localStorage.setItem(STORAGE_KEY, k);
      else localStorage.removeItem(STORAGE_KEY);
    } catch {}
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => setSettings((s) => ({ ...s, ...patch })), []);

  const setView = useCallback((v: View) => {
    setViewState(v);
    window.scrollTo({ top: 0 });
  }, []);

  const updateLead = useCallback((id: string, patch: Partial<Lead>, historyText?: string, kind: Lead["history"][number]["kind"] = "system") => {
    const at = new Date().toISOString();
    setLeads((old) => old.map((l) => (l.id === id ? { ...l, ...patch, updatedAt: at, history: historyText ? [...l.history, { at, text: historyText, kind }].slice(-60) : l.history } : l)));
  }, []);

  const setStage = useCallback((ids: string[], stage: Stage) => {
    const set = new Set(ids);
    const at = new Date().toISOString();
    setLeads((old) => old.map((l) => (set.has(l.id) && l.status !== stage ? { ...l, status: stage, updatedAt: at, history: [...l.history, { at, text: `Movido para ${STAGE_LABEL[stage]}`, kind: "stage" as const }].slice(-60) } : l)));
  }, []);

  const removeLeads = useCallback((ids: string[]) => {
    const set = new Set(ids);
    const removed = leadsRef.current.filter((l) => set.has(l.id));
    setLeads((old) => old.filter((l) => !set.has(l.id)));
    setOpenId((cur) => (cur && set.has(cur) ? null : cur));
    if (removed.length) {
      toast(`${removed.length} ${removed.length === 1 ? "lead removido" : "leads removidos"}`, {
        action: { label: "Desfazer", onClick: () => setLeads((old) => [...removed, ...old.filter((l) => !set.has(l.id))]) },
      });
    }
  }, []);

  const loadDemo = useCallback(() => {
    setLeads((old) => [...old.filter((l) => !l.demo), ...buildDemoLeads()]);
    toast.success("Dados de exemplo carregados", { description: "36 negócios fictícios em Fortaleza. Remova quando quiser em Ajustes." });
  }, []);

  const clearDemo = useCallback(() => {
    setLeads((old) => old.filter((l) => !l.demo));
    toast("Dados de exemplo removidos");
  }, []);

  const cancelSearch = useCallback(() => {
    cancelRef.current = true;
  }, []);

  const startSearch = useCallback(async ({ places, segments, radius, depth, excludeChains }: SearchInput) => {
    const log = (kind: ScanLog["kind"], text: string) =>
      setSearch((s) => ({ ...s, log: [...s.log, { id: ++logId.current, at: Date.now(), kind, text }].slice(-80) }));
    const jobs: { place: string; segment: string }[] = [];
    for (const place of places) for (const segment of segments) jobs.push({ place, segment });
    const total = jobs.length;
    cancelRef.current = false;
    setSearch({ ...IDLE, running: true, total, radius, log: [] });
    log("info", `Iniciando varredura: ${places.length} ${places.length === 1 ? "localidade" : "localidades"} × ${segments.length} ${segments.length === 1 ? "segmento" : "segmentos"}`);

    const centers = new Map<string, { lat: number; lon: number; label: string }>();
    const known = new Set<string>(leadsRef.current.map((l) => l.id));
    let added = 0, scanned = 0, withSite = 0, chains = 0, failures = 0;
    const errors: string[] = [];

    for (let j = 0; j < jobs.length; j++) {
      if (cancelRef.current) break;
      const { place, segment } = jobs[j];
      const segLabel = SEGMENT_BY_ID[segment]?.label || segment;
      setSearch((s) => ({ ...s, current: `${segLabel} · ${place}` }));
      for (let page = 0; page < depth; page++) {
        if (cancelRef.current) break;
        try {
          const requestBody = { location: place, segment, apiKey, radius, page, excludeChains, center: centers.get(place) };
          let data: { error?: string; leads: ApiLead[]; center?: { lat: number; lon: number; label: string }; scanned: number; withSite: number; chains: number; detailFailures: number; hasMore: boolean };
          if (typeof window !== "undefined" && window.__ORBITA_GITHUB_PAGES__) {
            data = await searchGeoapify(requestBody) as typeof data;
          } else {
            const response = await fetch("/api/search", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(requestBody),
            });
            data = (await response.json()) as typeof data;
            if (!response.ok) throw new Error(data.error || "Falha na consulta.");
          }
          if (data.center && !centers.has(place)) {
            centers.set(place, data.center);
            log("info", `Centro localizado: ${data.center.label}`);
          }
          const c = centers.get(place)!;
          const at = new Date().toISOString();
          const fresh: Lead[] = data.leads
            .filter((l) => !known.has(l.id))
            .map((l) => ({ ...l, demo: IS_PREVIEW || undefined, status: "novo", selected: false, starred: false, notes: "", followUp: "", value: 0, foundAt: at, updatedAt: at, history: [{ at, text: `Encontrado na busca por ${segLabel.toLowerCase()} em ${place}`, kind: "system" }] }));
          fresh.forEach((l) => known.add(l.id));
          added += fresh.length; scanned += data.scanned; withSite += data.withSite; chains += data.chains; failures += data.detailFailures;
          const blips = fresh.filter((l) => Number.isFinite(l.lat)).map((l) => {
            const bd = bearingDist(c, l.lat, l.lon);
            return { id: l.id, bearing: bd.bearing, dist: bd.dist, heat: (l.phone ? 1 : 0) + (l.instagramUrl ? 1 : 0) };
          });
          if (fresh.length) setLeads((old) => [...fresh, ...old]);
          setSearch((s) => ({ ...s, added, scanned, withSite, chains, blips: [...s.blips, ...blips].slice(-400) }));
          log(fresh.length ? "ok" : "info", `${segLabel} em ${place}${depth > 1 ? ` (página ${page + 1})` : ""}: ${data.scanned} fichas lidas, ${fresh.length} ${fresh.length === 1 ? "oportunidade nova" : "oportunidades novas"}`);
          if (data.detailFailures) log("warn", `${data.detailFailures} fichas não puderam ser verificadas`);
          if (!data.hasMore) break;
        } catch (e) {
          const msg = e instanceof SearchError ? e.message : e instanceof Error ? e.message : "erro";
          errors.push(`${place}: ${msg}`);
          log("error", `${segLabel} em ${place}: ${msg}`);
          if (/chave|limite/i.test(msg)) cancelRef.current = true;
          break;
        }
        await new Promise((r) => setTimeout(r, 700));
      }
      setSearch((s) => ({ ...s, done: j + 1 }));
    }

    const cancelled = cancelRef.current && errors.length === 0;
    setSearch((s) => ({ ...s, running: false, current: "", finishedAt: Date.now() }));
    log(errors.length ? "warn" : "ok", `${cancelled ? "Varredura interrompida" : "Varredura concluída"}: ${scanned} fichas, ${withSite} com site, ${chains} redes/franquias, ${added} oportunidades`);
    if (errors.length && errors.length >= jobs.length) {
      toast.error("A busca não foi concluída", { description: errors[0] });
    } else if (added) {
      toast.success(`${added} ${added === 1 ? "nova oportunidade" : "novas oportunidades"} na órbita`, {
        description: `${scanned} negócios analisados${failures ? ` · ${failures} sem verificação` : ""}`,
        action: { label: "Ver leads", onClick: () => setViewState("leads") },
      });
    } else {
      toast("Nenhuma oportunidade nova", { description: "Tente outro segmento, aumente o raio ou a profundidade." });
    }
  }, [apiKey]);

  const value = useMemo<Store>(() => ({
    ready, leads, setLeads, settings, updateSettings, apiKey, setApiKey, view, setView, openId, openLead: setOpenId,
    paletteOpen, setPaletteOpen, updateLead, setStage, removeLeads, loadDemo, clearDemo, search, startSearch, cancelSearch,
  }), [ready, leads, settings, updateSettings, apiKey, setApiKey, view, setView, openId, paletteOpen, updateLead, setStage, removeLeads, loadDemo, clearDemo, search, startSearch, cancelSearch]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
