"use client";
import { useMemo } from "react";
import { ArrowRight, CalendarClock, CircleDollarSign, Flame, Layers3, MessagesSquare, Radar, Sparkles, Target } from "lucide-react";
import { STAGES, STAGE_LABEL } from "@/lib/orbita/types";
import { leadScore, heatOf } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, followUpState, lastDays, formatDateBR, formatMoney, isLikelyMobile } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { SegmentIcon } from "./icons";
import { OrbitArt, ScoreBadge, Sparkline, STAGE_COLOR } from "./bits";

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Boa madrugada" : h < 12 ? "Bom dia" : h < 18 ? "Boa tarde" : "Boa noite";
}

export function Dashboard() {
  const { leads, settings, setView, openLead, loadDemo } = useOrbita();

  const d = useMemo(() => {
    const scored = leads.map((l) => ({ l, s: leadScore(l) }));
    const hot = scored.filter((x) => heatOf(x.s) === "quente");
    const byStage = Object.fromEntries(STAGES.map((s) => [s.id, 0])) as Record<string, number>;
    const bySeg = new Map<string, number>(), byArea = new Map<string, number>();
    let revenue = 0, pipelineValue = 0, phone = 0, wa = 0, ig = 0, email = 0;
    for (const { l } of scored) {
      byStage[l.status]++;
      bySeg.set(l.segment, (bySeg.get(l.segment) || 0) + 1);
      const area = l.suburb ? `${l.suburb} · ${cityOnly(l.city)}` : cityOnly(l.city);
      byArea.set(area, (byArea.get(area) || 0) + 1);
      if (l.status === "fechado") revenue += l.value || 0;
      if (l.status === "negociando") pipelineValue += l.value || 0;
      if (l.phone) phone++;
      if (isLikelyMobile(l)) wa++;
      if (l.instagramUrl) ig++;
      if (l.email) email++;
    }
    const window14 = lastDays(14);
    const days = window14.map((day) => leads.filter((l) => l.foundAt.slice(0, 10) === day).length);
    const contactedDays = window14.map((day) => leads.filter((l) => l.history.some((h) => h.at.slice(0, 10) === day && (h.kind === "contact" || h.kind === "stage"))).length);
    const followUps = leads.filter((l) => l.followUp && l.status !== "fechado" && l.status !== "perdido").sort((a, b) => a.followUp.localeCompare(b.followUp)).slice(0, 6);
    const topHot = scored.filter((x) => x.l.status === "novo" || x.l.status === "qualificado").sort((a, b) => b.s - a.s).slice(0, 6);
    const contacted = leads.length - byStage.novo - byStage.qualificado;
    const conv = contacted ? Math.round((byStage.fechado / contacted) * 100) : 0;
    return {
      hot: hot.length, byStage, revenue, pipelineValue, days, contactedDays, followUps, topHot, conv,
      segs: [...bySeg.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6),
      areas: [...byArea.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6),
      channels: [
        { label: "Telefone", n: phone }, { label: "Provável WhatsApp", n: wa }, { label: "Instagram", n: ig }, { label: "E-mail", n: email },
      ],
      talking: byStage.contatado + byStage.negociando,
    };
  }, [leads]);

  const name = settings.profile.name.split(" ")[0];
  const total = leads.length;
  const maxStage = Math.max(1, ...Object.values(d.byStage));

  return (
    <>
      <section className="hero fade-up">
        <OrbitArt className="hero-orbit" />
        <div style={{ position: "relative" }}>
          <span className="eyebrow">{greeting()}{name ? `, ${name}` : ""}</span>
          {total ? (
            <h2>{d.hot ? <>Você tem <em>{d.hot} {d.hot === 1 ? "lead quente" : "leads quentes"}</em> prontos para receber uma proposta.</> : <>Sua carteira tem <em>{total} negócios</em> sem site em órbita.</>}</h2>
          ) : (
            <h2>Seu radar está calibrado. Vamos achar os <em>primeiros clientes</em>?</h2>
          )}
          <p>{total ? `${d.talking} em conversa agora · ${d.byStage.fechado} fechados · taxa de fechamento de ${d.conv}% entre os contatados.` : "Escolha cidades e segmentos, e o Órbita encontra negócios sem site, pontua cada um e prepara a abordagem pelo WhatsApp."}</p>
          <div className="head-actions">
            <button className="btn btn-primary btn-lg" onClick={() => setView("busca")}><Radar /> Nova varredura</button>
            {total ? <button className="btn btn-lg" onClick={() => setView("pipeline")}>Abrir pipeline <ArrowRight /></button> : <button className="btn btn-lg" onClick={loadDemo}><Sparkles /> Explorar com exemplo</button>}
          </div>
        </div>
      </section>

      <div className="kpis">
        <div className="panel kpi fade-up" style={{ animationDelay: ".05s" }}>
          <div className="kpi-top">Leads na órbita <Layers3 /></div>
          <div className="kpi-val">{total}</div>
          <div className="kpi-foot"><b>+{d.days.slice(-7).reduce((a, b) => a + b, 0)}</b> nos últimos 7 dias</div>
          <Sparkline values={d.days} color="var(--cyan)" />
        </div>
        <div className="panel kpi fade-up" style={{ animationDelay: ".1s" }}>
          <div className="kpi-top">Leads quentes <Flame /></div>
          <div className="kpi-val">{d.hot}<small>/ {total}</small></div>
          <div className="kpi-foot">Score 65+ · telefone, Instagram e ticket</div>
        </div>
        <div className="panel kpi fade-up" style={{ animationDelay: ".15s" }}>
          <div className="kpi-top">Em conversa <MessagesSquare /></div>
          <div className="kpi-val">{d.talking}</div>
          <div className="kpi-foot">{d.pipelineValue ? <><b style={{ color: "var(--accent)" }}>{formatMoney(d.pipelineValue)}</b> em negociação</> : "Contatados + negociando"}</div>
          <Sparkline values={d.contactedDays} color="var(--violet)" />
        </div>
        <div className="panel kpi accent fade-up" style={{ animationDelay: ".2s" }}>
          <div className="kpi-top">Receita fechada <CircleDollarSign /></div>
          <div className="kpi-val num">{formatMoney(d.revenue)}</div>
          <div className="kpi-foot">{d.byStage.fechado} {d.byStage.fechado === 1 ? "projeto fechado" : "projetos fechados"} · {d.conv}% de conversão</div>
        </div>
      </div>

      <div className="grid-2">
        <section className="panel fade-up" style={{ animationDelay: ".25s" }}>
          <div className="panel-head">
            <div className="ico-box"><Target /></div>
            <div><h3>Funil de prospecção</h3><p>Onde cada negócio está agora</p></div>
            <div className="spacer" />
            <button className="btn btn-sm btn-ghost" onClick={() => setView("pipeline")}>Pipeline <ArrowRight /></button>
          </div>
          <div className="funnel">
            {STAGES.map((s) => (
              <div className="f-row" key={s.id} style={{ color: STAGE_COLOR[s.id] }}>
                <span className="f-label">{s.label}</span>
                <div className="f-track"><i style={{ width: `${(d.byStage[s.id] / maxStage) * 100}%` }} /></div>
                <span className="f-val" style={{ color: "var(--text)" }}>{d.byStage[s.id]}<small>{total ? Math.round((d.byStage[s.id] / total) * 100) : 0}%</small></span>
              </div>
            ))}
          </div>
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".3s" }}>
          <div className="panel-head">
            <div className="ico-box"><CalendarClock /></div>
            <div><h3>Próximos retornos</h3><p>Follow-ups agendados</p></div>
          </div>
          {d.followUps.length ? (
            <div className="rows">
              {d.followUps.map((l) => {
                const st = followUpState(l.followUp);
                return (
                  <button className="row-item" key={l.id} onClick={() => openLead(l.id)}>
                    <span className="seg-ico"><SegmentIcon id={l.segment} /></span>
                    <span className="grow"><strong>{l.name}</strong><small><span style={{ color: STAGE_COLOR[l.status] }}>{STAGE_LABEL[l.status]}</span> · {SEGMENT_BY_ID[l.segment]?.short} · {l.suburb || cityOnly(l.city)}</small></span>
                    <span className={`due ${st}`}>{st === "late" ? "Atrasado" : st === "today" ? "Hoje" : formatDateBR(l.followUp)}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="empty" style={{ padding: "36px 20px" }}><p style={{ margin: 0 }}>Nenhum retorno agendado. Defina datas de follow-up na ficha de cada lead.</p></div>
          )}
        </section>
      </div>

      <div className="grid-3">
        <section className="panel fade-up" style={{ animationDelay: ".35s" }}>
          <div className="panel-head">
            <div className="ico-box"><Flame /></div>
            <div><h3>Comece por aqui</h3><p>Maiores scores ainda sem contato</p></div>
          </div>
          {d.topHot.length ? (
            <div className="rows">
              {d.topHot.map(({ l, s }) => (
                <button className="row-item" key={l.id} onClick={() => openLead(l.id)}>
                  <span className="seg-ico"><SegmentIcon id={l.segment} /></span>
                  <span className="grow"><strong>{l.name}</strong><small>{l.suburb || cityOnly(l.city)}</small></span>
                  <ScoreBadge score={s} />
                </button>
              ))}
            </div>
          ) : <div className="empty" style={{ padding: "36px 20px" }}><p style={{ margin: 0 }}>Sem leads novos. Rode uma varredura para abastecer a fila.</p></div>}
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".4s" }}>
          <div className="panel-head">
            <div className="ico-box"><Layers3 /></div>
            <div><h3>Segmentos</h3><p>Onde estão suas oportunidades</p></div>
          </div>
          <div className="bars">
            {d.segs.length ? d.segs.map(([id, n]) => (
              <div className="bar-row" key={id}>
                <div><span>{SEGMENT_BY_ID[id]?.label || id}</span><b>{n}</b></div>
                <div className="bar-track"><i style={{ width: `${(n / d.segs[0][1]) * 100}%` }} /></div>
              </div>
            )) : <p className="muted" style={{ margin: 0, fontSize: 13 }}>Sem dados ainda.</p>}
          </div>
        </section>

        <section className="panel fade-up" style={{ animationDelay: ".45s" }}>
          <div className="panel-head">
            <div className="ico-box"><MessagesSquare /></div>
            <div><h3>Canais de contato</h3><p>Como chegar em cada negócio</p></div>
          </div>
          <div className="bars">
            {d.channels.map((c) => (
              <div className="bar-row" key={c.label}>
                <div><span>{c.label}</span><b>{total ? Math.round((c.n / total) * 100) : 0}%</b></div>
                <div className="bar-track"><i style={{ width: `${total ? (c.n / total) * 100 : 0}%`, background: "linear-gradient(90deg, var(--accent), #fb923c)" }} /></div>
              </div>
            ))}
            {d.areas.length > 0 && <div className="hint" style={{ marginTop: 4 }}>Região mais densa: <b style={{ color: "var(--text)" }}>{d.areas[0][0]}</b> ({d.areas[0][1]} leads)</div>}
          </div>
        </section>
      </div>
    </>
  );
}
