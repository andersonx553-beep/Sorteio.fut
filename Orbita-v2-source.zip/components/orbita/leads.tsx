"use client";
import { useMemo, useState } from "react";
import { ArrowDown, ArrowDownToLine, ArrowUp, ArrowUpDown, Radar, Search, Sparkles, Star, Trash2, X } from "lucide-react";
import type { Lead, Stage } from "@/lib/orbita/types";
import { STAGES } from "@/lib/orbita/types";
import { leadScore, heatOf, type Heat } from "@/lib/orbita/score";
import { SEGMENT_BY_ID } from "@/lib/orbita/segments";
import { cityOnly, exportCsv, followUpState, formatDateBR, formatDistance, isLikelyMobile, normalizeText, relativeTime } from "@/lib/orbita/utils";
import { useOrbita } from "./store";
import { SegmentIcon } from "./icons";
import { CheckBox, ContactDots, OrbitArt, ScoreBadge } from "./bits";
import { toast } from "sonner";

type SortKey = "score" | "name" | "foundAt" | "followUp";
type Channel = "todos" | "whatsapp" | "telefone" | "instagram" | "sem-contato";

export function LeadsView() {
  const { leads, setLeads, openLead, setStage, removeLeads, setView, loadDemo, updateLead } = useOrbita();
  const [query, setQuery] = useState("");
  const [stage, setStageFilter] = useState<Stage | "todos">("todos");
  const [seg, setSeg] = useState("todos");
  const [city, setCity] = useState("todos");
  const [heat, setHeat] = useState<Heat | "todos">("todos");
  const [channel, setChannel] = useState<Channel>("todos");
  const [starred, setStarred] = useState(false);
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: "score", dir: -1 });
  const [limit, setLimit] = useState(60);

  const scores = useMemo(() => new Map(leads.map((l) => [l.id, leadScore(l)])), [leads]);
  const segOptions = useMemo(() => [...new Set(leads.map((l) => l.segment))], [leads]);
  const cityOptions = useMemo(() => [...new Set(leads.map((l) => l.city))], [leads]);

  const filtered = useMemo(() => {
    const q = normalizeText(query);
    const out = leads.filter((l) => {
      if (stage !== "todos" && l.status !== stage) return false;
      if (seg !== "todos" && l.segment !== seg) return false;
      if (city !== "todos" && l.city !== city) return false;
      if (starred && !l.starred) return false;
      if (heat !== "todos" && heatOf(scores.get(l.id) || 0) !== heat) return false;
      if (channel === "whatsapp" && !isLikelyMobile(l)) return false;
      if (channel === "telefone" && !l.phone) return false;
      if (channel === "instagram" && !l.instagramUrl) return false;
      if (channel === "sem-contato" && (l.phone || l.instagramUrl || l.email)) return false;
      if (q && !normalizeText(`${l.name} ${l.city} ${l.suburb} ${l.address} ${l.category} ${l.notes}`).includes(q)) return false;
      return true;
    });
    const k = sort.key;
    out.sort((a, b) => {
      let r = 0;
      if (k === "score") r = (scores.get(a.id) || 0) - (scores.get(b.id) || 0);
      else if (k === "name") r = a.name.localeCompare(b.name, "pt-BR");
      else if (k === "foundAt") r = a.foundAt.localeCompare(b.foundAt);
      else r = (a.followUp || "9999").localeCompare(b.followUp || "9999");
      return r * sort.dir;
    });
    return out;
  }, [leads, query, stage, seg, city, heat, channel, starred, sort, scores]);

  const selected = leads.filter((l) => l.selected);
  const allSel = filtered.length > 0 && filtered.every((l) => l.selected);
  const someSel = filtered.some((l) => l.selected);
  const activeFilters = [stage !== "todos", seg !== "todos", city !== "todos", heat !== "todos", channel !== "todos", starred, !!query].filter(Boolean).length;

  const setSel = (ids: Set<string>, v: boolean) => setLeads((old) => old.map((l) => (ids.has(l.id) ? { ...l, selected: v } : l)));
  const clearSel = () => setLeads((old) => old.map((l) => (l.selected ? { ...l, selected: false } : l)));
  const sortBtn = (key: SortKey, label: string) => (
    <button className={sort.key === key ? "on" : ""} onClick={() => setSort((s) => ({ key, dir: s.key === key ? ((s.dir * -1) as 1 | -1) : key === "name" || key === "followUp" ? 1 : -1 }))}>
      {label}{sort.key === key ? (sort.dir === 1 ? <ArrowUp /> : <ArrowDown />) : <ArrowUpDown style={{ opacity: 0.4 }} />}
    </button>
  );
  const resetFilters = () => { setQuery(""); setStageFilter("todos"); setSeg("todos"); setCity("todos"); setHeat("todos"); setChannel("todos"); setStarred(false); };

  function doExport(rows: Lead[]) {
    try {
      exportCsv(rows, (l) => scores.get(l.id) || 0);
      toast.success(`CSV com ${rows.length} ${rows.length === 1 ? "lead" : "leads"} baixado`, { description: "Abre direto no Excel ou Google Planilhas." });
    } catch {
      toast.error("Não foi possível baixar o CSV neste navegador.");
    }
  }

  if (!leads.length) {
    return (
      <>
        <Head count={0} onExport={() => {}} />
        <section className="panel">
          <div className="empty">
            <OrbitArt className="empty-art" />
            <h3>Nenhum lead em órbita ainda</h3>
            <p>Rode sua primeira varredura para encontrar negócios sem site — ou explore o painel com dados fictícios de Fortaleza.</p>
            <div className="row">
              <button className="btn btn-primary" onClick={() => setView("busca")}><Radar /> Nova varredura</button>
              <button className="btn" onClick={loadDemo}><Sparkles /> Carregar exemplo</button>
            </div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Head count={leads.length} onExport={() => doExport(selected.length ? selected : filtered)} exportLabel={selected.length ? `Exportar ${selected.length}` : `Exportar ${filtered.length}`} />
      <section className="panel fade-up">
        <div className="toolbar">
          <div className="input-wrap">
            <Search />
            <input className="input" placeholder="Buscar por nome, bairro, nota…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Buscar leads" />
          </div>
          <select className="select" value={stage} onChange={(e) => setStageFilter(e.target.value as Stage | "todos")} aria-label="Filtrar por estágio">
            <option value="todos">Todos os estágios</option>
            {STAGES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
          <select className="select" value={heat} onChange={(e) => setHeat(e.target.value as Heat | "todos")} aria-label="Filtrar por temperatura">
            <option value="todos">Qualquer score</option>
            <option value="quente">Quentes (65+)</option>
            <option value="morno">Mornos (42–64)</option>
            <option value="frio">Frios (&lt;42)</option>
          </select>
          <select className="select" value={channel} onChange={(e) => setChannel(e.target.value as Channel)} aria-label="Filtrar por canal">
            <option value="todos">Qualquer canal</option>
            <option value="whatsapp">Provável WhatsApp</option>
            <option value="telefone">Com telefone</option>
            <option value="instagram">Com Instagram</option>
            <option value="sem-contato">Sem contato</option>
          </select>
          {segOptions.length > 1 && (
            <select className="select" value={seg} onChange={(e) => setSeg(e.target.value)} aria-label="Filtrar por segmento">
              <option value="todos">Todos os segmentos</option>
              {segOptions.map((s) => <option key={s} value={s}>{SEGMENT_BY_ID[s]?.label || s}</option>)}
            </select>
          )}
          {cityOptions.length > 1 && (
            <select className="select" value={city} onChange={(e) => setCity(e.target.value)} aria-label="Filtrar por localidade">
              <option value="todos">Todas as localidades</option>
              {cityOptions.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          )}
          <button className="chip" aria-pressed={starred} onClick={() => setStarred((v) => !v)}><Star />Favoritos</button>
          {activeFilters > 0 && <button className="btn btn-sm btn-ghost" onClick={resetFilters}><X /> Limpar filtros</button>}
          <span className="count num">{filtered.length} de {leads.length}</span>
        </div>

        {filtered.length ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th><CheckBox checked={allSel ? true : someSel ? "mixed" : false} onChange={(v) => setSel(new Set(filtered.map((l) => l.id)), v)} label="Selecionar todos os resultados" /></th>
                  <th>{sortBtn("name", "Negócio")}</th>
                  <th>{sortBtn("score", "Score")}</th>
                  <th>Localização</th>
                  <th>Canais</th>
                  <th>Estágio</th>
                  <th>{sortBtn("followUp", "Retorno")}</th>
                  <th>{sortBtn("foundAt", "Encontrado")}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, limit).map((l) => {
                  const s = scores.get(l.id) || 0;
                  const fu = followUpState(l.followUp);
                  return (
                    <tr key={l.id} className={l.selected ? "sel" : ""} onClick={() => openLead(l.id)} tabIndex={0} onKeyDown={(e) => { if (e.key === "Enter") openLead(l.id); }}>
                      <td><CheckBox checked={l.selected} onChange={(v) => setSel(new Set([l.id]), v)} label={`Selecionar ${l.name}`} /></td>
                      <td>
                        <div className="biz">
                          <span className="seg-ico"><SegmentIcon id={l.segment} /></span>
                          <div style={{ minWidth: 0 }}>
                            <strong>
                              <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{l.name}</span>
                              <button className={`star ${l.starred ? "on" : ""}`} aria-label={l.starred ? "Remover dos favoritos" : "Favoritar"} onClick={(e) => { e.stopPropagation(); updateLead(l.id, { starred: !l.starred }); }}><Star fill={l.starred ? "currentColor" : "none"} /></button>
                              {l.demo && <span className="demo-tag">exemplo</span>}
                            </strong>
                            <small>{SEGMENT_BY_ID[l.segment]?.short || l.category}{l.socialOnly ? " · usa rede social como site" : ""}</small>
                          </div>
                        </div>
                      </td>
                      <td><ScoreBadge score={s} /></td>
                      <td className="loc">{l.suburb || cityOnly(l.city)}<small>{[l.address, formatDistance(l.distance) && `${formatDistance(l.distance)} do centro`].filter(Boolean).join(" · ") || l.city}</small></td>
                      <td><ContactDots lead={l} /></td>
                      <td onClick={(e) => e.stopPropagation()}>
                        <select className={`pill st-${l.status}`} value={l.status} onChange={(e) => setStage([l.id], e.target.value as Stage)} aria-label={`Estágio de ${l.name}`}>
                          {STAGES.map((st) => <option key={st.id} value={st.id}>{st.label}</option>)}
                        </select>
                      </td>
                      <td>{l.followUp ? <span className={`due ${fu}`}>{fu === "late" ? "Atrasado" : fu === "today" ? "Hoje" : formatDateBR(l.followUp)}</span> : <span className="faint">—</span>}</td>
                      <td className="faint" style={{ whiteSpace: "nowrap" }}>{relativeTime(l.foundAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty">
            <h3>Nada nesse filtro</h3>
            <p>Ajuste os filtros para ver outros negócios.</p>
            <button className="btn" onClick={resetFilters}>Limpar filtros</button>
          </div>
        )}
        {filtered.length > limit && (
          <div className="tbl-foot"><span>Mostrando {limit} de {filtered.length}</span><button className="btn btn-sm" onClick={() => setLimit((n) => n + 100)}>Carregar mais</button></div>
        )}
        <div className="tbl-foot" style={{ borderTop: "1px solid var(--line)" }}>
          <span>Dados © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a> · ODbL. “Sem site” = sem site no OSM; confira antes de abordar.</span>
        </div>
      </section>

      {selected.length > 0 && (
        <div className="bulk" role="region" aria-label="Ações em lote">
          <b>{selected.length} {selected.length === 1 ? "selecionado" : "selecionados"}</b>
          <select className="select" value="" onChange={(e) => { if (e.target.value) { setStage(selected.map((l) => l.id), e.target.value as Stage); toast.success(`${selected.length} movidos para ${STAGES.find((s) => s.id === e.target.value)?.label}`); } }} aria-label="Mover selecionados">
            <option value="">Mover para…</option>
            {STAGES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
          <button className="btn btn-sm" onClick={() => doExport(selected)}><ArrowDownToLine /> CSV</button>
          <button className="btn btn-sm btn-danger" onClick={() => removeLeads(selected.map((l) => l.id))}><Trash2 /> Remover</button>
          <button className="btn btn-sm btn-ghost btn-icon" onClick={clearSel} aria-label="Limpar seleção"><X /></button>
        </div>
      )}
    </>
  );
}

function Head({ count, onExport, exportLabel }: { count: number; onExport: () => void; exportLabel?: string }) {
  const { setView } = useOrbita();
  return (
    <div className="page-head fade-up">
      <div>
        <span className="eyebrow">Carteira</span>
        <h1>Seus leads, <em>em ordem de prioridade.</em></h1>
        <p>Ordenados pelo score: quem tem WhatsApp, Instagram ativo e ticket alto aparece primeiro. Clique em um negócio para abrir a ficha completa.</p>
      </div>
      <div className="head-actions">
        <button className="btn" disabled={!count} onClick={onExport}><ArrowDownToLine /> {exportLabel || "Exportar CSV"}</button>
        <button className="btn btn-primary" onClick={() => setView("busca")}><Radar /> Nova varredura</button>
      </div>
    </div>
  );
}
