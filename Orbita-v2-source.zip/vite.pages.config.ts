import path from "node:path";
import { fileURLToPath } from "node:url";
import tailwindcss from "@tailwindcss/postcss";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const projectRoot = path.dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  root: path.resolve(projectRoot, "github-pages"),
  base: "/Sorteio.fut/",
  publicDir: path.resolve(projectRoot, "public"),
  plugins: [react()],
  resolve: { alias: { "@": projectRoot } },
  css: { postcss: { plugins: [tailwindcss()] } },
  build: { outDir: path.resolve(projectRoot, "pages-dist"), emptyOutDir: true },
});
